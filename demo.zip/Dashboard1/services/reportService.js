dashboardApp.service("reportService",function(){

		var reportData={};
		this.setReportData=function(enrichedData){
			reportData=enrichedData;
		};
		this.getReportData=function()
		{
			return reportData;
		}


});