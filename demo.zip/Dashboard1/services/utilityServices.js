dashboardApp.service("utilityService",function(){


		this.parser=function(serviceData,relevantReport){
			
			var yearsArray=Object.keys(serviceData.testDetails);
			
			var masterserviceobj={};
			var year_and_reportMapper={};
			for(i=0;i<yearsArray.length;i++)
			{
				year_and_reportMapper[yearsArray[i].toString()]=Object.keys(serviceData.testDetails[yearsArray[i]]);

			}
			
			var testingList=["OBX_Hemogram","OBX_ADULT","OBX_LIPID PROFILE","OBX_Sample OBR ID","OBX_Sample Report"];
			for(j=0;j<testingList.length;j++)
			{
				
				for(k=0;k<yearsArray.length;k++)
				{
					if(year_and_reportMapper[yearsArray[k]].includes(testingList[j]))
					{
						
						var yearstring=yearsArray[k];
						
						if(masterserviceobj[testingList[j]]==undefined)
						{
								masterserviceobj[testingList[j]]={};

						}
						if(masterserviceobj[testingList[j]][yearsArray[k]]==undefined)
								{
								masterserviceobj[testingList[j]][yearsArray[k]]=[];
								}
					masterserviceobj[testingList[j]][yearsArray[k]].push(serviceData.testDetails[yearsArray[k]][testingList[j]]);
					}
				}
			}
			window.masterobj=masterserviceobj;
			
			return masterserviceobj;


		}

		this.getReportList=function(bgsegment)
		{
			console.log(bgsegment);
				var ReportMapping={
					      "Buttocks":["Lipid","Urine","Eyes"],
  					      "Shoulder_s":["Lipid","Urine","Eyes"],
					      "Back_Upper":["Lipid","Urine","Eyes"],
					      "Brain":["Lipid","Urine","Eyes"],
					      "Chest":["Lipid","Urine","Eyes"],
					      "Eye_s":["Lipid","Urine","Eyes"],
					      "Back_Lower":["Lipid","Urine","Eyes"],
					      "Thumb":["Lipid","Urine","Eyes"],
					      "Teeth":["Lipid","Urine","Eyes"],
					      "Finger_s":["Lipid","Urine","Eyes"],
					      "Hand":["Lipid","Urine","Eyes"],
					      "Hip":["Lipid","Urine","Eyes"],
					      "Abdomen":["Lipid","Urine","Eyes"],
					      "Ankle":["Lipid","Urine","Eyes"],
					      "Wrist":["Lipid","Urine","Eyes"],
					      "Head_Soft_Tissue":["Lipid","Urine","Eyes"],
					      "Arm_Upper":["Lipid","Urine","Eyes"],
					      "Leg_Lower":["Lipid","Urine","Eyes"],
					      "Neck_Soft_Tissue":["Lipid","Urine","Eyes"]

				};
				return ReportMapping[bgsegment];




		}


 
		this.expectedData={
				Lipid:{
						"2016":{val_ranges:[[90,59,100,120],[100,60,200,200]],labels:['LDL','HDL','Triglycerides','Total']},
						"2015":{val_ranges:[[70,59,90,120],[100,60,200,200]],labels:['LDL','HDL','Triglycerides','Total']},
						"2014":{val_ranges:[[80,65,100,120],[100,60,200,200]],labels:['LDL','HDL','Triglycerides','Total']}

				},
				Eyes:{
						"2016":{val_ranges:[-2.5,-0.5,90,180],labels:["Left","Right","Cylineder","Spherical"]},
						"2015":{val_ranges:[-2.5,-0.25,90,180],labels:["Left","Right","Cylineder","Spherical"]},
				},
				Blood:{
						"2016":{val_ranges:[14.10,43.20,4.87,88.70,29][17,50,5.5,100,32],labels:["Hemoglobin","Cell Volume","RBC Count","MCV","MCHC"]},
						"2015":{val_ranges:[13.10,41.19,4.87,82.70,29][17,50,5.5,100,32],labels:["Hemoglobin","Cell Volume","RBC Count","MCV","MCHC"]},
						"2014":{val_ranges:[14.10,40.20,4.87,84.70,29][17,50,5.5,100,32],labels:["Hemoglobin","Cell Volume","RBC Count","MCV","MCHC"]},
				}





		};




});