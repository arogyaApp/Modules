dashboardApp.controller("reportController",function($scope,$window,$timeout,$mdDialog,utilityService){


//repport
//$scope.reportData=window.masterobj;
//console.log(window.masterobj);
$scope.myreport='hello';
$scope.tabledata=[];
$scope.getRow=function(obval)
{
  console.log(obval);
  var keyarr=Object.keys(obval.observationDetails);
 console.log(keyarr);
 console.log(obval);
 var jsonobj=JSON.parse(obval.observationDetails[keyarr[0]]);
 console.log(jsonobj.Observation_identifier.Observation_Text);
 console.log(jsonobj.Result_unit_reference_range);
 console.log(jsonobj.Observation_value);
 var rowdata={parameter:jsonobj.Observation_identifier.Observation_Text,range:jsonobj.Result_unit_reference_range,val:jsonobj.Observation_value};
 var rowtext="<td>"+rowdata.parameter+"</td><td>"+rowdata.range+"</td><td>"+rowdata.val+"</td>"
 return rowdata;
}
$scope.reportgen=function(obxvals)
{

  console.log("!!!!!!!!!!!!!!!!!!!!!11");
  var ob_array=obxvals[0];
  console.log(ob_array);
  //var tabledata=[{parameter:"a",value:50,range:40}];

  for(k=0;k<ob_array.length;k++)
  {
    console.log(ob_array[k].observationDetails);
    var objkeyarray=Object.keys(ob_array[k].observationDetails);
    console.log(objkeyarray);
    console.log(JSON.parse(ob_array[k].observationDetails[objkeyarray[0]]));
    var convertedData=JSON.parse(ob_array[k].observationDetails[objkeyarray[0]]);
    $scope.tabledata[k]={
      parameter:convertedData.Observation_identifier.Observation_Text,
      range:convertedData.Result_unit_reference_range,
      value:convertedData.Observation_value
    };
  
  }
  console.log($scope.tabledata);

 //console.log(tabledata);
 //$scope.tabledata=tabledata;
  


};



//side handler
$scope.isOpen = false;

      $scope.demo = {
        isOpen: false,
        count: 0,
        selectedDirection: 'left'
      };

//dialog handler

$scope.showAdd = function(ev) {
    $mdDialog.show({
      controller: DialogController,
      templateUrl:"views/detailedpopup.php",
      targetEvent: ev,
    })
    .then(function(answer) {
      $scope.alert = 'You said the information was "' + answer + '".';
    }, function() {
      $scope.alert = 'You cancelled the dialog.';
    });
  };




//dialog controller
  function DialogController($scope, $mdDialog) {
    $scope.popupcontent="Report content goes here";
    $scope.ReportName="Serum Report";
        $scope.labels = ["January", "February", "March", "April", "May", "June", "July"];
  $scope.series = ['Series A', 'Series B'];
  $scope.data = [
    [65, 59, 80, 81, 56, 55, 40],
    [28, 48, 40, 19, 86, 27, 90]
  ];

        $scope.label2 = ["January", "February", "March", "April", "May", "June", "July"];
  $scope.series = ['Series A', 'Series B'];
  $scope.data2 = [
    [65, 59, 80, 81, 56, 55, 40],
    [28, 48, 40, 19, 86, 27, 90]
  ];
  $scope.hide = function() {
    $mdDialog.hide();
  };
  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  $scope.answer = function(answer) {
      $mdDialog.hide();
    $mdDialog.hide(answer);
  };
  
};




});