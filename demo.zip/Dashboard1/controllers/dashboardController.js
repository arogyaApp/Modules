dashboardApp.controller("dashboardController",function($scope,$http,$timeout, $mdBottomSheet, $mdToast,$mdSidenav,$mdDialog,utilityService,reportService){


function init()
{
  $.ajax({
      method:"post",
      url:"json/latestresponse.json",
      success:function(){
        //REPORT DATA
        console.log(arguments[0].testDetails);
        var reportlist=[];
        var yearsarray=Object.keys(arguments[0].testDetails);
        for(i=0;i<yearsarray.length;i++)
        {
          var currentobj=Object.keys(arguments[0].testDetails[yearsarray[i]]);
          console.log(currentobj);
          for(j=0;j<currentobj.length;j++)
          {
            reportlist.push({year:yearsarray[i],reportName:currentobj[j],observations:arguments[0].testDetails[yearsarray[i]][currentobj[j]],timestamp:arguments[0].testDetails[yearsarray[i]][currentobj[j]][0].timeStamp});
          }
        }
        console.log(reportlist);
        window.reportData=reportlist;
        
      },
      error:function(){
        console.log(arguments[0]);
      }
    });
}

//marking bodyparts
$scope.markbodyParts=function()
{

  var bodyreference=document.getElementsByTagName("svg")[0];
  var segmentsArray=Object.keys(arguments[0]);
  for(i=0;i<segmentsArray.length;i++)
  {
    if(arguments[0][segmentsArray[i]]=='R')
    {
       try
         {
          document.getElementById(segmentsArray[i]).style.fill="#ff4081";
         }catch(e){}
    }
  }
}

//getting report mapping on segment click
$scope.getReportList=function(bodyPart)
{
  
}



//get customer data on load
angular.element(document).ready(function(){
 
    /* var config = {
      headers:  {
       
        'Accept': 'application/json'
     
    }
};*/
   /* $http.get("http://localhost:8080/Arogya/ArogyaServer?customer=999999999",config).then(function(response){
   
      console.log(response.data);
      console.log(JSON.stringify(response.data));
      var customersinfo=JSON.stringify(response.data);
      //success handler
      //1.set data on local
      window.localStorage.setItem("customersData", customersinfo);
      //2.mark body parts
      $scope.markbodyParts(response.data.flags)
    },function(){
      console.log(arguments);
    });*/

    //1.getting data
     var userData=JSON.parse(window.localStorage.getItem("finalResponse"));
    //2.mark bodyparts
    $scope.markbodyParts(userData.flagDetails);
    //3.get enriched data


});

 $scope.toggleLeft = buildToggler('left');
    $scope.toggleRight = buildToggler('right');
    $scope.selectedTab=0;
    function buildToggler(componentId) {
    	
      return function() {
        $mdSidenav(componentId).toggle();
      };
  }

      $scope.fetchDetails=function(){
     
     
    $scope.reportList=utilityService.getReportList(arguments[0].target.id);
    console.log($scope.reportList);
    $scope.$apply(function(){
      $scope.localdata=JSON.parse(window.localStorage.getItem("finalResponse");
       

    });
    $scope.$watch("localdata",function(){
      $scope.enrichedData=utilityService.parser( $scope.localdata,$scope.reportList);
    });
  
     console.log($scope.enrichedData);
     
     reportService.setReportData($scope.enrichedData);
     console.log("data from report");
     $scope.selectedTab=1;
     console.log(reportService.getReportData());
    
      };

      $scope.switchedTab=function(tabindex)
      {
      
        $scope.selectedTab=tabindex;
      }


});
