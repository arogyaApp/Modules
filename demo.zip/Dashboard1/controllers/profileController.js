dashboardApp.controller("profileController",function($scope,$http){


$scope.checkAjax=function(){
	$http({url:"http://localhost:8080/Arogya/ArogyaServer?customer=P0000665544",method:"GET",data:{customer:"PI32323232"}}).then(function(){console.log("success");console.log(arguments)},function(){console.log("error")});
};


  $scope.userData={
      Name:"Sameer Mathur",
      Age:27,
      City:"Pune, India",
      ContactNo:"8932376451",
      Address:"B-432,Dreams Paradise, Kalyani Nagar",
      Weight:"78kg"
  };


	 var imagePath = 'https://mdbootstrap.com/img/Photos/Avatars/img%20%2820%29.jpg';


 $scope.todos = [
      {
        face : imagePath,
        what: 'Pain in left arm',
        who: 'Min Li Chan',
        when: '3:08PM',
        notes: " Little dislocation occured in left arm"
      },
      {
        face : imagePath,
        what: 'Click on a button to Add Alergies',
        who: 'Symptoms',
        when: 'First Observed',
        notes: "Remarks "
      },
      {
        face : imagePath,
        what: 'Brunch this weekend?',
        who: 'Min Li Chan',
        when: '3:08PM',
        notes: " I'll be in your neighborhood doing errands"
      },
      {
        face : imagePath,
        what: 'Brunch this weekend?',
        who: 'Min Li Chan',
        when: '3:08PM',
        notes: " I'll be in your neighborhood doing errands"
      },
      {
        face : imagePath,
        what: 'Brunch this weekend?',
        who: 'Min Li Chan',
        when: '3:08PM',
        notes: " I'll be in your neighborhood doing errands"
      },
    ];



});