  
     
     
   

  /**
   * Configuration method that is used to define a preset for the upcoming panel
   * element. Each parameter in the preset is an available parameter in the
   * `$mdPanel.create` and `$mdPanel.open` methods. When the parameters are
   * defined here, they overwrite the default parameters for any panel that the
   * preset is requested for.
   * @param {!MdPanelProvider} $mdPanelProvider Provider method of the MdPanel
   *     API.
   */
  
 



/**
Copyright 2016 Google Inc. All Rights Reserved. 
Use of this source code is governed by an MIT-style license that can be foundin the LICENSE file at http://material.angularjs.org/HEAD/license.
**/