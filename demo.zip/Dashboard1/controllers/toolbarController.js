dashboardApp.controller("toolbarController",function($scope){

	$scope.patientName="Sameer Mathur";
	$scope.healthscore=88;
	$scope.sugarlevel="7.8 mmol/L";
	$scope.lastrecordedBP="118/78";
	$scope.sex="Male";
	$scope.age="24 Years";


});
