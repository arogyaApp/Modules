 
   dashboardApp.controller('PanelProviderCtrl', PanelProviderCtrl);
   dashboardApp.controller('PanelMenuCtrl', PanelMenuCtrl);
  function PanelMenuCtrl(mdPanelRef) {
    this.closeMenu = function() {
      mdPanelRef && mdPanelRef.close();
    };
  }



  

  function PanelProviderCtrl($mdPanel) {
  	
  
    this.navigation = {
      name: 'navigation',
      items: [
        'Home',
        'About',
        'Contact'
      ]
    };
   
    

    this.showMenu = function($event, menu) {
      /**
       * The request to open the panel has two arguments passed into it. The
       * first is a preset name passed in as a string. This will request a
       * cached preset and apply its configuration parameters. The second is an
       * object containing parameters that can only be filled through a
       * controller. These parameters represent configuration needs associated
       * with user interaction, panel position, panel animation, and other
       * miscellaneous needs.
       */
      $mdPanel.open('demoPreset', {
        id: 'menu_' + menu.name,
        position: $mdPanel.newPanelPosition()
            .relativeTo($event.srcElement)
            .addPanelPosition(
              $mdPanel.xPosition.ALIGN_START,
              $mdPanel.yPosition.BELOW
            ),
        locals: {
          items: menu.items
        },
        openFrom: $event
      });
    };
  }