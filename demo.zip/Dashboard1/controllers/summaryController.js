  dashboardApp.controller("summaryController",function($scope){
  $scope.ok="dfksjflsdkfj";
   $scope.labels = ['LDL','HDL','Triglycerides','Total'];
    $scope.series = ['Series A', 'Series B'];
    $scope.data = [
     [59,78,90,100],
    [60,90,110,120]
    ];
    $scope.onClick = function (points, evt) {
      console.log(points, evt);
    };
    $scope.datasetOverride = [{ yAxisID: 'y-axis-1' }, { yAxisID: 'y-axis-2' }];
    $scope.options = {
      scales: {
        yAxes: [
          {
            id: 'y-axis-1',
            type: 'linear',
            display: true,
            position: 'left'
          },
          {
            id: 'y-axis-2',
            type: 'linear',
            display: true,
            position: 'right'
          }
        ]
      }
    };
  $scope.basicDetails=[

  		{label:"BMI",value:"overweight: 28",cls:"basicCard redcard"},
  		{label:"HealthScore",value:88,cls:"basicCard bluecard"},
  		{label:"Weight",value:"81kg",cls:"basicCard greencard"},
  		{label:"Height",value:"5'11",cls:"basicCard yellowcard"}

  ];


  //donut
    $scope.doughnutlabels = ["Download Sales", "In-Store Sales", "Mail-Order Sales"];
    $scope.doughnutdata = [300, 500, 100];


  var imagePath = 'https://mdbootstrap.com/img/Photos/Avatars/img%20%2820%29.jpg';

     $scope.phones = [
        {
          type: 'Home',
          number: '(555) 251-1234',
          options: {
            icon: 'communication:phone'
          }
        },
        {
          type: 'Cell',
          number: '(555) 786-9841',
          options: {
            icon: 'communication:phone',
            avatarIcon: true
          }
        },
        {
          type: 'Office',
          number: '(555) 314-1592',
          options: {
            face : imagePath
          }
        },
        {
          type: 'Offset',
          number: '(555) 192-2010',
          options: {
            offset: true,
            actionIcon: 'communication:phone'
          }
        }
      ];
      $scope.todos = [
        {
          face : imagePath,
          what: 'Pain in left arm',
          who: 'Min Li Chan',
          when: '3:08PM',
          notes: " Little dislocation occured in left arm"
        },
        {
          face : imagePath,
          what: 'Click on a button to Add Alergies',
          who: 'Symptoms',
          when: 'First Observed',
          notes: "Remarks "
        }
      ];

  alert("summary");
  console.log(JSON.parse(window.localStorage.getItem("finalResponse")).testDetails);
  var dataset=JSON.parse(window.localStorage.getItem("finalResponse")).testDetails;
  var datalabels=[];
  var graphset=[];
  var rangeset=[];
  var datakeys=Object.keys(dataset);
  for(i=0;i<datakeys.length;i++)
  {
    console.log("*******************");
    console.log(dataset[datakeys[i]]);
    var ref=dataset[datakeys[i]];
    var innerKeys=Object.keys(ref);
    for(j=0;j<innerKeys.length;j++)
    {
      console.log(ref[innerKeys[j]]);
      var obxarray=ref[innerKeys[j]];
      for(k=0;k<obxarray.length;k++)
      {
        console.log(obxarray[k]);
       
        var obxval=obxarray[k].observationDetails;
        var obkey=Object.keys(obxval);
        console.log(JSON.parse(obxval[obkey[0]]));
        var obxdata=JSON.parse(obxval[obkey[0]]);
        if(!((obxdata.Abnormal_flags=='') || (obxdata.Abnormal_flags=='N')))
        {
            console.log("abnormal case");
            datalabels.push(obxdata.Observation_identifier.Observation_Text);
            if(isNaN(parseInt(obxdata.Observation_value)))
            {
               graphset.push(0);
            }
            else
            {
            graphset.push(parseInt(obxdata.Observation_value));
          }
            console.log("@@@@@");
            try{
            console.log((obxdata.Result_unit_reference_range).split("-")[1]);
            rangeset.push(parseInt((obxdata.Result_unit_reference_range).split("-")[1]));
          }catch(e){
            rangeset.push(0);
          }
           // rangeset.push(parseInt(((obxdata.Result_unit_reference_range).split("-")[1])));
        }
      }
    }
  }
  console.log(datalabels);console.log(graphset);console.log(rangeset);
        $scope.labels = datalabels;
    $scope.series = ['Range', 'Value'];
    
    $scope.data = [
      graphset,
     rangeset
    ];

  });