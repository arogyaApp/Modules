var dashboardApp=angular.module('dashboardApp', ['ngMaterial',"chart.js","ngMessages","ng-fusioncharts","ngAnimate"]);

 dashboardApp.config(PanelProviderConfig);

 
 

function PanelProviderConfig($mdPanelProvider) {
    $mdPanelProvider.definePreset('demoPreset', {
      attachTo: angular.element(document.body),
      controller: PanelMenuCtrl,
      controllerAs: 'ctrl',
      template: '' +
          '<div class="menu-panel" md-whiteframe="4" style="background-color:#fff;pointer-events:auto">' +
          '  <div class="menu-content">' +
          '    <div class="menu-item" ng-repeat="item in ctrl.items">' +
          '      <button class="md-button">' +
          ' <input type="checkbox"></input>   '+ 
          '        <span>{{item}}</span>' +
          '      </button>' +
          '    </div>' +
          '    <md-divider></md-divider>' +
          '    <div class="menu-item">' +
          '      <button class="md-button" ng-click="ctrl.closeMenu()">' +
          '        <span>Close Menu</span>' +
          '      </button>' +
          '    </div>' +
          '  </div>' +
          '</div>',
      panelClass: 'menu-panel-container',
      focusOnOpen: false,
      zIndex: 200,

      propagateContainerEvents: true,
      groupName: 'menus'
    });
  }





  