Highcharts.chart('linecontainer', {

   
 height:200,
    yAxis: {
         floor: 0,
        ceiling: 200,
        tickPixelInterval:20,
        title: {
            text: 'Blood Pressure',

        }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
    },

    plotOptions: {
        series: {
            pointStart: 2010
        }
    },

    series: [{
        name: 'Installation',
        data: [120,118,134,128,118]
    }]

});