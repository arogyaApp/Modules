Highcharts.setOptions({
    colors: ['#ccc', '#03a9f4', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4']
});

Highcharts.chart('container2', {
    chart: {
        type: 'bar'
    },
    color:['#ccc','#03a9f4'],
    title: {
        text: 'Haemoglobin Report'
    },
    xAxis: {
        categories: ['Haemoglobin']
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Haemoglobin(hg)'
        }
    },
    legend: {
        reversed: true
    },
    plotOptions: {
        series: {
            stacking: 'normal'
        }
    },
    series: [ {
        name: 'Haemoglobin(hg)',
        data: [22]
    },
    {
        name: 'Total Count Per mg -40',
        data: [18]
    },
    
    ]
});