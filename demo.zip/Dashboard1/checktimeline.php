<!DOCTYPE html>
<html>
<head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular.min.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-animate.min.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-aria.min.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-messages.min.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
<script src="node_modules/angular-chart.js/dist/angular-chart.min.js"></script>
<script type="text/javascript" src="angular-fusioncharts.min.js"></script>
<script type="text/javascript">

  var app=angular.module("appmod",["chart.js","ngMessages","ng-fusioncharts"]);
  app.controller("CollapsibleCheck",function($scope){
    var responseobject={"customerid":"ACH8305371","flags":{"Buttocks":"R","Shoulder_s":"R","Back_Upper":"R","Brain":"G","Chest":"G","Eye_s":"G","Back_Lower":"G","Thumb":"G","Teeth":"R","Finger_s":"R","Hand":"R","Hip":"R","Abdomen":"G","Ankle":"G","Wrist":"R","Head_Soft_Tissue":"G","Arm_Upper":"G","Leg_Lower":"G","Neck_Soft_Tissue":"G"},"reportlist":["OBX_Lipid_20100518161040\":{\"Observation_identifier\": {\"Observation_identifier.1\": \"13457-7\",\"Observation_identifier.2\": \"LDL Cholesterol\",\"Observation_identifier.3\": \"LN\"},\"Observation_value\": 90,\"Result_unit_reference_range\": \"< 99\",\"Result_units_of_measurement\": \"mg\/dL\",\"Sequence_number\": 1,\"Sequence_number1\": \"F\",\"Sequence_number6\": {\"Sequence_number6.2\": \"DOE\",\"Sequence_number6.3\": \"JOHN\"},\"Value_type\": \"NM\",\"Value_type3\": {\"Value_type3.1\": \"AccuLabs\",\"Value_type3.10\": \"10D987432\",\"Value_type3.6\": \"CLIA\"},\"Value_type4\": {\"Value_type4.1\": \"432 Administration Ave.\",\"Value_type4.3\": \"St. Louis\",\"Value_type4.4\": \"MO\",\"Value_type4.5\": 63146},\"Value_type5\": {\"Value_type5.2\": \"Smith\",\"Value_type5.3\": \"John\",\"Value_type5.6\": \"Dr.\",\"Value_type5.7\": \"MD\"}}","OBX_Lipid_20100518161040\":{\"Abnormal_flags\": \"H\",\"Observation_identifier\": {\"Observation_identifier.1\": \"14646-4\",\"Observation_identifier.2\": \"HDL Cholesterol\",\"Observation_identifier.3\": \"LN\"},\"Observation_value\": 60,\"Result_unit_reference_range\": \"40-59\",\"Result_units_of_measurement\": \"mg\/dL\",\"Sequence_number\": 2,\"Sequence_number1\": \"F\",\"Sequence_number6\": {\"Sequence_number6.2\": \"DOE\",\"Sequence_number6.3\": \"JOHN\"},\"Value_type\": \"NM\",\"Value_type3\": {\"Value_type3.1\": \"AccuLabs\",\"Value_type3.10\": \"10D987432\",\"Value_type3.6\": \"CLIA\"},\"Value_type4\": {\"Value_type4.1\": \"432 Administration Ave.\",\"Value_type4.3\": \"St. Louis\",\"Value_type4.4\": \"MO\",\"Value_type4.5\": 63146},\"Value_type5\": {\"Value_type5.2\": \"Smith\",\"Value_type5.3\": \"John\",\"Value_type5.6\": \"Dr.\",\"Value_type5.7\": \"MD\"}}","OBX_Lipid_20100518161040\":{\"Observation_identifier\": {\"Observation_identifier.1\": \"14647-2\",\"Observation_identifier.2\": \"Total Cholesterol\",\"Observation_identifier.3\": \"LN\"},\"Observation_value\": 120,\"Result_unit_reference_range\": \"< 199\",\"Result_units_of_measurement\": \"mg\/dL\",\"Sequence_number\": 3,\"Sequence_number1\": \"F\",\"Sequence_number6\": {\"Sequence_number6.2\": \"DOE\",\"Sequence_number6.3\": \"JOHN\"},\"Value_type\": \"NM\",\"Value_type3\": {\"Value_type3.1\": \"AccuLabs\",\"Value_type3.10\": \"10D987432\",\"Value_type3.6\":0,\"Value_type4.4\": \"MO\",\"Value_type4.5\": 63146},\"Value_type5\": {\"Value_type5.2\": \"Smith\",\"Value_type5.3\": \"John\",\"Value_type5.6\": \"Dr.\",\"Value_type5.7\": \"MD\"}}","OBX_Lipid_20100518161040\":{\"Observation_identifier\": {\"Observation_identifier.1\": \"14927-8\",\"Observation_identifier.2\": \"Triglycerides\",\"Observation_identifier.3\": \"LN\"},\"Observation_value\": 100,\"Result_unit_reference_range\": \"< 149\",\"Result_units_of_measurement\": \"mg\/dL\",\"Sequence_number\": 4,\"Sequence_number1\": \"F\",\"Sequence_number6\": {\"Sequence_number6.2\": \"DOE\",\"Sequence_number6.3\": \"JOHN\"},\"Value_type\": \"NM\",\"Value_type3\": {\"Value_type3.1\": \"AccuLabs\",\"Value_type3.10\": \"10D987432\",\"Value_type3.6\": \"CLIA\"},\"Value_type4\": {\"Value_type4.1\": \"432 Administration Ave.\",\"Value_type4.3\": \"St. Louis\",\"Value_type4.4\": \"MO\",\"Value_type4.5\": 63146},\"Value_type5\": {\"Value_type5.2\": \"Smith\",\"Value_type5.3\": \"John\",\"Value_type5.6\": \"Dr.\",\"Value_type5.7\": \"MD\"}}"]};

console.log(responseobject);


//parsing obx for object
var reportObject=responseobject.reportlist;
var labelarray=[];
  var valuearray=[];
  var rangearray=[];
  var unitarray=[];
for(i=0;i<reportObject.length;i++)
{
  console.log(reportObject[i]);
  var str="'"+reportObject[i] ;
  var obxrep=JSON.parse(str.substring(str.indexOf(':')+1));
  //var repname=reportObject[i].substring(0,reportObject[i].indexOf(':')-1);
  //console.log(repname);
  console.log(obxrep);
  valuearray.push(obxrep.Observation_value);
  rangearray.push(obxrep.Result_unit_reference_range);
  labelarray.push(obxrep.Observation_identifier['Observation_identifier.2']);
  unitarray.push(obxrep.Result_units_of_measurement);

  

}
console.log(valuearray);
console.log(rangearray);
console.log(unitarray);
console.log(labelarray);

     var obj={
        "2017":[{msg:"This is report1"},{msg:"This is report2"},{msg:"This is report 3"}],
        "2016":[{msg:"This is report1"},{msg:"This is report2"},{msg:"This is report 3"}],
        "2015":[{msg:"This is report1"},{msg:"This is report2"},{msg:"This is report 3"}],
        "2014":[{msg:"This is report1"},{msg:"This is report2"},{msg:"This is report 3"}]

     };
     console.log(obj);
     var reportkeys=Object.keys(obj);
      $scope.yearpanels=reportkeys
      $scope.reportobj=obj;

  $scope.labels = labelarray;
  $scope.series = ['Series A', 'Series B'];
  $scope.data = [
    valuearray,
    rangearray
  ];


var getHistoricalData=function(reportName)
{
     var historydata={};
      if(reportName=="serum")
      {
        console.log("inside");
        historydata.historicalLabel=labelarray;
        historydata.historicalrange=rangearray;
        historydata.historicalval=[
        {"2016":[90,60,120,100]},
        {"2015":[82,69,110,100]},
        {"2014":[87,55,100,100]}
        ]
      }
      else if(reportName=="eyes")
      {
        historydata.historicalLabel=["spherical","cylindrical","axis"];
        historydata.historicalrange=[];
        historydata.historicalval=[
        {"2016":[2.50,-0.75,90,-2.00,-2.25,180]},
        {"2015":[2.50,-0.5,90,-2.00,-2.20,180]},
        {"2014":[2.0,-0.75,90,-2.00,-2.25,180]}
      ]
    }
    else{}
   console.log(historydata);
    return historydata;
}
$scope.timeline=["01-05-2017","05-07-2016","03-06-2015"];
 $scope.reportarray=["serum","eyes"];
 $scope.reportListed=["Lipid","Blood","Eyes"]
 $scope.reportsdata=function()
 {

  var reportlist=["serum","eyes"];
    var masterarray=[];
      for(i=0;i<reportlist.length;i++)
        {
            console.log(reportlist[i]);
          var str={};
             str[reportlist[i]]=getHistoricalData(reportlist[i]);
            masterarray.push(str);

           
        }
        console.log(masterarray)
        return masterarray;
 };


   }



  );

  </script>
  
</head>
<body ng-app="appmod" ng-controller="CollapsibleCheck" style="background-color:#f0f0f0">


<div class="modal fade" tabindex="-1" role="dialog" id="myModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Timeline</h4>
      </div>
      <div class="modal-body">
       <div class="row">
      <div clas="col col-sm-12 col-md-6 col-lg-12" ng-repeat="(name,data) in reportsdata">

          <div class="well">
              <table class="table table-striped">
                  

              </table>

          </div>

      </div>

</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->



	<div class="container-fluid ">


    <br/>
			<div class="row justify-content-center">
					<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6"  ng-repeat="year in yearpanels" desc>
							 
               <div class="well" style="background-color:#fff;padding:0px;box-shadpw:2px 3px 4px #afafaf" >

							 <div class="panel-heading" style="background-color:#6cb6f1;color:#fff;padding:20px;border-radius:10px 10px 0px 0px ">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#{{year}}_box" style="color:#fff"><span class="color:#fff"><i class="glyphicon glyphicon-circle-arrow-right"></i> {{reportListed[$index]}}</span></a>
        
          <span class="glyphicon glyphicon glyphicon-time pull-right" style="color:#fff" data-toggle="modal" data-target="#myModal" ng-click="reportsdata()"></span>
        </h4>
      </div>
        <div id="{{year}}_box" class=" panel-collapse collapse" >
   <div class="panel-body">

    			<div ng-repeat="reports in reportobj[year]">
    					<div class="panel panel-info" style="border:0px solid #fff">
    						<div class="panel panel-primary panel-heading" style="background-color:#fff;padding:20px;bprder:0px solid #fff">
						        <h4 class="panel-title">
						          <a data-toggle="collapse" href="#{{key}}_{{$index}}" style="color:#000;text-decoration:none"><i class="glyphicon glyphicon-ok-circle" style="color:#18bd9b;font-size:22px"></i> &nbsp Report{{$index+1}}: Time:{{timeline[$index]}}</a>
						        </h4>
      						</div>
      						<div id="{{year}}_{{$index}}" class="panel-collapse collapse">
      								<div class="panel-body">
      										
      										   

      								</div>

      						</div>
      					</div>
    			</div>




  </div>

					</div>
				</div>

			</div>


	</div>



<span ng-click="reportsdata()">adta</span>




 
</body>
</html>