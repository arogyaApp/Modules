
<md-toolbar class="md-primary" flex  style="width:100%" ng-controller="toolbarController">

<div class="row header_row" layout="row" style="height:48px;box-shadow:2px 3px 4px #afafaf;background-color:#FFC200">

	<div flex="75">
			<h3 style="margin:20px;margin-left:30px;margin-top:10px">Arogya</h3>
	
	</div>
	<div class="buttonholder" flex="25" style="margin-top:10px" class="push-right">
					<span ng-click="switchedTab(0)" style="outline:none"><i class="glyphicon glyphicon-bell"></i>&nbsp Summary </span> &nbsp
					<span ng-click="switchedTab(1)" style="outline:none"><i class="glyphicon glyphicon-align-justify"></i>&nbsp Report </span>&nbsp
					<span ng-click="switchedTab(2)" style="outline:none"><i class="fa fa-user"></i>&nbsp Profile</span>&nbsp
			</div>

</div>


 <div class="row" layout="row" style="box-shadow:2px 3px 4px #afafaf">

 		<div flex="25" class="" style="display:flex;background-color:#00579c">
 			<div style="order:1;margin-left:20px">
 				 <img src="https://media.licdn.com/mpr/mpr/shrinknp_200_200/p/1/000/207/23d/3edbfaa.jpg" class="md-avatar" alt="user"  style="40px;height:40px;border-radius:20px;margin-top:20px"/>

 			</div>
 			<div style="order:2" style="margin-top:20px;">
 				<div style="margin-top:10px">
 					<span style="font-size:24px;padding:10px">{{patientName}} </span><br/>
 					<span style="font-size:18px;padding:10px">Pune,INDIA</span>
 				</div>
 			</div>

 		</div>
 		<div flex="25" class="" style="display:flex;#ccc;background-color:#0277bd">
 			<div style="order:1;margin-left:20px">
 					<h1><i class="fa fa-user"></i></h1>

 			</div>
 			<div style="order:2" style="padding-top:30px">
 				<div style="margin-top:7px">
 					<span style="font-size:24px;padding:10px">{{sex}} </span><br/>
 					<span style="font-size:18px;padding:10px">{{age}}</span>
 				</div>
 			</div>

 		

 		</div>

 		<div flex="25" class="" style="display:flex;background-color:#0288d1">

 			

 			<div style="order:1;margin-left:20px">
 					<h1><i class="fa fa-dashboard"></i></h1>

 			</div>
 			<div style="order:2" style="margin-top:20px">
 				<div style="margin-top:7px">
 					<span style="font-size:24px;padding:10px">Health Score</span><br/>
 					<span style="font-size:18px;padding:10px">{{healthscore}}</span>
 				</div>
 			</div>


 		</div>
 		<div flex="25" class="" style="display:flex;background-color:#039be6">
 			

 			<div style="order:1;margin-left:20px">
 					<h1><i class="fa fa-heartbeat"></i></h1>

 			</div>
 			<div style="order:2" style="margin-top:20px">
 				<div style="margin-top:7px">
 					<span style="font-size:24px;padding:10px">Last Recorded BP</span><br/>
 					<span style="font-size:18px;padding:10px">{{lastrecordedBP}}</span>
 				</div>
 			</div>
 		</div>


 </div>
   
    </md-toolbar>