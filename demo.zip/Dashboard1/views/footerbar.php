<md-bottom-sheet class="md-grid" layout="column">
  <div layout="row" layout-align="center center" ng-cloak>
    <h4>Since <code>clickOutsideToClose = false</code>, drag down or press ESC to close</h4>
  </div>
  <div ng-cloak>
    <md-list flex layout="row" layout-align="center center">
      <md-list-item ng-repeat="item in items">
        <div>
          <md-button class="md-grid-item-content" ng-click="listItemClick($index)">
            <md-icon md-svg-src="{{item.icon}}"></md-icon>
            <div class="md-grid-text"> {{ item.name }} </div>
          </md-button>
        </div>
      </md-list-item>
    </md-list>
  </div>
</md-bottom-sheet>