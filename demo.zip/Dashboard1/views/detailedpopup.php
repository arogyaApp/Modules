 <md-dialog aria-label="Mango (Fruit)" style="width:70%;text-align:center"> 
 <md-content class="md-padding"> 
 
 <md-toolbar>
 	<md-label style="padding:20px">{{ReportName}}</md-label>

</md-toolbar>
	<div style="width:70%;padding:20px;margin:0px auto">
		<h3>Serum Report :2017</h3>
 <canvas class="chart chart-line" chart-data="data" chart-labels="labels" 
    chart-series="series" chart-click="onClick"></canvas>

	<h3>Serum Report :2016</h3>
 	
 
 	<table class="table-striped">
 			<tr>
 			<th>Timeline</th>
 			
 			<th ng-repeat="lbl in labels5">{{lbl}}-{{data5.range[$index]}}</th>

 		</tr>



 		<tr ng-repeat="rec in data5">
 			<td>{{rec.timestamp}}</td>
 			
 			<td ng-repeat="obs in rec.val">{{obs}}</td>
 			
 		</tr>
 		
 		
 	</tr>
 	</table>

	</div>

	
	


  </md-content> <div class="md-actions" layout="row">
  <span flex></span> <md-button ng-click="answer()"> Cancel </md-button> 
  <md-button ng-click="answer(\'useful\')" class="md-primary"> Save </md-button> 
</div>
</md-dialog>
     