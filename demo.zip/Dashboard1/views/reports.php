
<div class="container" ng-controller="reportController">
    <!-- Page header -->
    <!-- /Page header -->
    <!-- Timeline -->
   

         <span class="glyphicon glyphicon-time" style="font-size:45px;margin:0px auto;width:100%;text-align:center;margin-left:-60px;padding:20px">
            <br/>
            <span style="font-size:22px;font-family:Oswald;margin-left:-20px;margin-top:-4px">Historical Reports for Patient</span>

         </span>     


    <div class="timeline"><br/><br/>
       
        <div class="line text-muted"></div>
        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

            <div class="panel panel-default" ng-repeat="(key,value) in enrichedData">
                <div class="panel-heading " role="tab" id="heading1">
                   <div class=" icon"> <i class="glyphicon glyphicon-plus-sign" style="margin-left:2px;font-size:22px;padding:5px;background-color:#f0f0f0"></i>

                    </div>
                     <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#{{key}}" aria-expanded="true" aria-controls="collapse1">
         {{key}}
        </a>

      </h4>

                </div>
                <div id="{{key}}" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading1">
                    <div class="panel-body">
                       

                          <span ng-repeat="(year,report) in value">
                                <br/>
                             
                                                             
                                    <h3 style="font-family:Oswald">Details for {{key}} Report for {{year}}</h3>
                                    <table class="table table-striped report_table" ng-init="reportgen(report)" id="{{year}}_index" style="margin-top:5px">
                                            <tr>
                                            <th style="width:100px">Parameter</th>
                                            <th style="min-width:90px">Value</th>
                                            <th style="min-width:190px">Range</th>
                                        </tr>
                                            <tr ng-repeat="obx in report[0]">
                                                <td>{{(getRow(obx)).parameter}}</td>
                                                <td style="width:33%">{{(getRow(obx)).val}}</td>
                                                <td style="width:33%">{{(getRow(obx)).range}}</td>
                                                
                                </tr>
                                    
                                    </table>
                                
                       
                    </div>
                </div>
            </div>
            <!-- /Panel -->
           
    </div>
<!-- end of container -->