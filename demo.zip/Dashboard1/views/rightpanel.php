<md-content flex layout-padding class="rightpanel">
       <div ng-cloak>
  <md-content>
    <md-tabs md-dynamic-height="" md-border-bottom="" md-selected="selectedTab" style="margin-top:-58px">
     <md-tab-label=""></md-tab>
      <md-tab label="SUMMARY">
     
        <?php include 'views/summary.php' ?>
      </md-tab>


      <md-tab label="REPORTS" id="reports_tab">

    <?php include 'views/reports.php' ?>
      </md-tab>
      <md-tab label="PROFILE">
       <?php include 'views/profile.php' ?>
      </md-tab>
    </md-tabs>
  </md-content>
</div>
   </md-content>