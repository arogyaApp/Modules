<div ng-controller="profileController">
<div layout="row" layout-xs="column">
	<div flex=33>
				<md-card class="basicCardBig">
				<img src="https://yt3.ggpht.com/-T6hmXUPeCMw/AAAAAAAAAAI/AAAAAAAAAAA/9hojytIBJ1Q/s900-c-k-no-mo-rj-c0xffffff/photo.jpg"/>

			</md-card>
		</div> 
		<div flex=66>
			
						<!--<button class="btn btn-info" ng-click="checkAjax()" style="display:none">Ajaxcheck</button> -->
				<md-card class="basicCardBig" >
					
		
			<table class="table table-striped" style="border:0px solid #fff">
					<tr ng-repeat="(key,value) in userData" style="border:0px solid #fff">
							<td style="width:30%" style="border:0px solid #fff">{{key}}</td>
							<td style="width:70%">{{value}}</td>

					</tr>

			</table>

			





	</div>



			  </md-card>
		


   
		


</div>




<div layout="row" layout-xs="column">
		<div flex=100>
				<md-card class="basicCardBig">

				  <md-list flex>
        <md-subheader class="md-no-sticky">Doctor's Comments</md-subheader>
        <md-list-item class="md-3-line" ng-repeat="item in todos" ng-click="null">
          <img ng-src="{{item.face}}?{{$index}}" class="md-avatar" alt="{{item.who}}" />
          <div class="md-list-item-text" layout="column">
            <h3>{{ item.who }}</h3>
            <h4>{{ item.what }}</h4>
            <p>{{ item.notes }}</p>
          </div>
        </md-list-item>
        <md-divider ></md-divider>
        <md-subheader class="md-no-sticky">2 line item</md-subheader>
        <md-list-item class="md-2-line">
          <img ng-src="{{todos[0].face}}?20" class="md-avatar" alt="{{todos[0].who}}" />
          <div class="md-list-item-text">
            <h3>{{ todos[0].who }}</h3>
            <p>Secondary text</p>
          </div>
        </md-list-item>
	<div ng-repeat="(key,value) in reports">
		{{key}}:{{reports[key]}}
	</div>

			</md-card>
		</div>


</div>
</div>

