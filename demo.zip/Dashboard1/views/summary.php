<div ng-controller="summaryController">
  
<div layout="row" layout-xs="column">
    <div flex=50>
        <md-card class="basicCardBig" style="height:250px">
<canvas id="bar" class="chart chart-bar"
  chart-data="data" chart-labels="labels"> chart-series="series"
</canvas

    </md-card>

    </div>

    <div flex=50>
        <md-card class="basicCardBig" style="height:250px">
<canvas id="line" class="chart chart-line" chart-data="data"
chart-labels="labels" chart-series="series" chart-options="options"
chart-dataset-override="datasetOverride" chart-click="onClick">
</canvas>

    </md-card>

    </div>
  </div>
   







<div layout="row" layout-xs="column" >
 <div flex=50>
           <md-card class="basicCardBig"  >

             <md-content>
      <md-list flex>
         <md-subheader class="md-no-sticky" style="background-color:#0288d1"><b style="color:#fff;font-size:20px">Doctor's Comments</b></md-subheader>
        <md-list-item class="md-3-line" ng-repeat="item in todos" ng-click="null">
          <img ng-src="{{item.face}}?{{$index}}" class="md-avatar" alt="{{item.who}}" />
          <div class="md-list-item-text" layout="column">
            <h3>{{ item.who }}</h3>
            <h4>{{ item.what }}</h4>
            <p>{{ item.notes }}</p>
          </div>
        </md-list-item>
        <md-divider ></md-divider>
        <md-subheader class="md-no-sticky">2 line item</md-subheader>
        <md-list-item class="md-2-line">
          <img ng-src="{{todos[0].face}}?20" class="md-avatar" alt="{{todos[0].who}}" />
          <div class="md-list-item-text">
            <h3>{{ todos[0].who }}</h3>
            <p>Secondary text</p>
          </div>
        </md-list-item>




       </md-card>
    </div>


     <div flex=50>
           <md-card class="basicCardBig" >

             <md-content>
      <md-list flex>

        <md-subheader class="md-no-sticky" style="background-color:#0288d1;margin-top:-7px"><b style="color:#fff;font-size:20px">Reminders /Appointment</b></md-subheader>
       <md-subheader class="md-no-sticky">Add Alergies</md-subheader>
        <md-list-item class="md-2-line">
          <h3> <i class="glyphicon glyphicon-plus-sign md-avatar" alt="{{item.who}}" ></i></h3>
          <div class="md-list-item-text">
            <h3>Add Alergies</h3>
            <p>Remarks </p>
          </div>
        </md-list-item>
        <md-divider ></md-divider>
        <md-list-item class="md-3-line" ng-repeat="item in todos" ng-click="null">
         <h3> <i class="glyphicon glyphicon-bell md-avatar" alt="{{item.who}}" ></i></h3>
          <div class="md-list-item-text" layout="column">
            <h3>{{ item.who }}</h3>
            <h4>Book a Apointment with Doctor</h4>
            <p>Note - Open from 11am to 8:30pm</p>
          </div>
        </md-list-item>
        
       




       </md-card>
    </div>

 <!-- <div ng-repeat="details in basicDetails" flex=25>
        <md-card class={{details.cls}}><h1>{{details.label}} <h1> <h2 style="margin-top:-40px">{{details.value}}</h2><md-card>

  </div>
-->

</div>

</div>


