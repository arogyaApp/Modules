<!DOCTYPE html>
<html>
<head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="reportstyle.css">
  <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.4/Chart.min.js"></script>
<script type="text/javascript" src="https://code.angularjs.org/1.5.5/angular-route.min.js"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" type="text/css">




</head>
<body ng-app="reportDash" ng-controller="maincontroller">


	<!--modal content -->
	<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog" >
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content" style="width:800;height:600px;overflow-y:scroll">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">{{modalheader}}</h4>
      </div>
      <div class="modal-body" style="width:100%;height:100%" >
       
        		  <iframe src="http://localhost/dicom/dicom/build/" style="width:100%;border:0px solid #000;height:100%;overflow-y:scroll"></iframe>



      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<!--maincontainer-->
<div class="container" style="width:100%" id="maincontainer">

		
		<div class="row" id="mainrow" style="margin:0px">
		<!-- tabholder -->
			<div class="col col-sm-12 col-md-12 col-lg-1 w3-center w3-animate-left" id="tabholder">
				
				<div class="row">
						<div class="col col-12">
								<div class="well btnholder">
									<h3><i class="glyphicon glyphicon-list" style="color:#fff"></i></h3>
								</div>
						</div>
						<div class="col col-12">
								<div class="well btnholder">
									<h3><a href="http://localhost/dicom/dicom/build" target="_blank" ><i class="glyphicon glyphicon-share" style="color:#fff" data-toggle="modal" data-target="blank" href="http://localhost/dicom/dicom/build"></i></a></h3>
								</div>
						</div>
						<div class="col col-12">
								<div class="well btnholder">
									<h3><i class="glyphicon glyphicon-time" style="color:#fff"></i></h3>
								</div>
						</div>
						<div class="col col-12">
								<div class="well btnholder">
									<h3><i class="glyphicon glyphicon-list" style="color:#fff"></i></h3>
								</div>
						</div>
						



				</div>



			</div>

		<!-- profileholder -->
			<div class="col col-sm-12 col-md-12 col-lg-3 w3-center w3-animate-left" id="profileholder">
			
			<img class="img-responsive profilepic" src="http://cached.imagescaler.hbpl.co.uk/resize/scaleWidth/614/offlinehbpl.hbpl.co.uk/news/ORP/B4034D5B-B9CD-0FDA-A4A4B94A79E709491-20160616043202649.jpg" alt="Chania" style="border-bottom:5px solid #fbfa75">

			<div class="row">

					<div class="col col-sm-12 col-md-6 col-lg-6" style="border-right:1px dotted #ccc">

						<div class="well transparentwell" style="padding:0px" >
							
							<div class="datasection datasection-left" >
							<h3>27</h3>
							<span style="margin-top:-10px">Age</span>
						</div>


						</div>
					</div>

					<div class="col col-sm-12 col-md-6 col-lg-6" >
						<div class="well transparentwell" style="text-align:left;padding:0px">
							
							<div class="datasection datasection-left">
							<h3>74Kg</h3>
							<span style="margin-top:-10px">Weight</span>
						</div>
						</div>
					</div>

			</div>


			<div class="row">

					<div class="col col-sm-12 col-md-12 col-lg-12">
						<div class="well transparentwell">
							<div class="datasection datasection-left">
							<h3>182cm</h3>
							<span style="margin-top:-10px">Height</span>
						</div>


						</div>
					</div>

					

			</div>

			<div class="row">

				<div class="col col-sm-12 col-md-12 col-lg-12">
						<div style="text-align:center">
<svg version="1.1" style="height:200px;margin-top:-20px;left:30px auto" ng-click="fetchDetails($event)" style="outline:none;left:40px" id="Map" fill=rgba(00,00,00,0.5) class="gen-by-synoptic-designer" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 355 628" xml:space="preserve"><polygon id="Brain" title="" points="180,23,177,18,173,15,169,13,165,12,161,11,156,11,151,11,146,11,142,13,138,15,134,17,131,20,128,23,126,27,124,31,123,35,123,40,184,40,184,34,182,28" /><polygon id="Eye_s" title="" points="136,50,142,46,148,50,142,54" /><polygon id="Teeth" title="" points="147,73,162,73,159,77,150,77" /><polygon id="Shoulder_s" title="" points="91,115,97,112,104,110,110,108,117,107,124,104,119,127,104,143,95,157,70,148,71,140,72,133,77,126,82,119" /><polygon id="Eye_s" title="" points="160,51,166,47,172,51,166,55" /><polygon id="Shoulder_s" title="" points="232,122,224,116,217,112,208,110,201,108,194,105,187,103,190,127,204,132,218,156,240,152,239,139,235,129" /><polygon id="Chest" title="abnormaility detected " points="100,164,99,154,109,141,121,129,126,105,135,101,156,107,180,99,187,103,190,127,204,132,216,151,213,163,210,172,203,181,192,184,183,183,175,178,137,177,128,184,118,185,109,183,104,177,101,172" /><polygon id="Neck_Soft_Tissue" title="" points="155,106,181,98,177,92,175,83,169,89,162,94,152,94,143,91,135,85,134,92,132,99" /><polygon id="Arm_Upper" title="" points="71,212,98,220,102,211,103,195,100,184,98,173,95,157,69,149,68,160,71,169,70,183,70,196" /><polygon id="Arm_Upper" title="" points="241,166,242,181,241,201,243,213,213,221,210,211,212,195,211,180,214,166,216,157,241,153" /><polygon id="Hand" title="" points="30,325,31,337,25,345,25,357,34,357,42,359,49,358,59,356,60,348,61,337,59,328,37,318" /><polygon id="Finger_s" title="" points="55,374,49,380,42,387,34,389,27,386,24,380,24,372,25,362,34,361,42,363,57,361" /><polygon id="Thumb" title="" points="11,354,10,345,19,332,28,324,29,338,23,347,17,352" /><polygon id="Buttocks" title="" points="110605,250343,110619,250344,110631,250342,110659,250338,110658,250316,110657,250302,110541,250301,110537,250317,110537,250337,110573,250342,110590,250342,110598,250336" /><polygon id="Hip" title="" points="541,389,538,369,536,356,538,331,551,337,562,340,560,359,556,386" /><polygon id="Hip" title="" points="-40650,18343,-40659,18343,-40657,18356,-40656,18367,-40656,18378,-40655,18388,-40636,18386,-40633,18347" /><polygon id="Back_Lower" title="" points="651,251,645,239,550,238,546,254,544,264,543,276,542,286,543,293,654,293,651,276,652,264" /><polygon id="Back_Upper" title="" points="1645,-17124,1654,-17156,1650,-17180,1650,-17197,1651,-17219,1645,-17235,1550,-17234,1545,-17220,1543,-17211,1545,-17200,1544,-17192,1545,-17184,1546,-17173,1543,-17154,1547,-17131,1555,-17119,1572,-17107,1618,-17106,1631,-17113" /><polygon id="Head_Soft_Tissue" title="" points="408-2683565,81-983634,408-2683571,81-983623,408-2683580,81-983617,408-2683589,81-983613,408-2683599,81-983613,408-2683606,81-983614,408-2683613,81-983618,408-2683620,81-983623,408-2683625,81-983633,408-2683625,81-983644,408-2683624,81-983653,408-2683622,81-983664,408-2683569,81-983663,408-2683565,81-983646" /><polygon id="Wrist" title="" points="37,315,42,298,70,307,61,327" /><polygon id="Wrist" title="" points="-101246,64311,-101254,64326,-101281,64316,-101274,64303" /><polygon id="Ankle" title="" points="134,593,157,593,157,586,154,579,135,580,135,587" /><polygon id="Ankle" title="" points="161,588,161,583,163,579,185,579,184,584,184,589,185,594,160,594" /><polygon id="Leg_Lower" title="" points="189,563,196,540,205,510,204,500,202,489,164,489,159,503,160,514,162,545,163,578,185,578" /><polygon id="Leg_Lower" title="" points="151,488,117,485,114,492,113,504,114,519,116,534,121,544,125,554,129,564,134,578,154,577,154,532,156,512,154,501" /><polygon id="Elbow" title="" points="64,227,99,239,100,222,70,212" /><polygon id="Elbow" title="" points="213,234,213,223,244,215,247,227" /><polygon id="Arm_Lower" title="" points="95,261,97,251,98,240,63,228,56,246,51,263,43,296,72,305,83,285" /><polygon id="Wrist" title="" points="247,312,273,301,278,315,254,324" /><polygon id="Hand" title="" points="282,335,284,323,278,315,254,324,253,334,253,343,256,352,267,353,277,353,287,350,286,343" /><polygon id="Finger_s_" title="" points="262,375,259,368,256,353,272,355,289,351,289,368,289,377,285,381,279,386,270,382" /><polygon id="Thumb" title="" points="286,324,282,337,289,344,295,350,302,351,305,347,291,327" /><polygon id="Arm_Lower" title="" points="248,227,256,241,261,258,264,275,272,301,248,311,240,302,224,276,218,262,215,251,213,235" /><polygon id="Abdomen" title="" points="104,279,105,259,110,243,107,226,102,214,103,193,98,174,118,185,128,184,137,178,175,178,183,183,195,184,203,180,210,172,211,195,205,221,204,243,207,260,208,270,208,280,163,283" /><polygon id="Toe_s_" title="" points="117,612,121,607,128,603,148,603,145,609,143,616,136,620,126,619,118,618" /><polygon id="Foot" title="" points="156,603,128,602,134,598,136,594,156,594" /><polygon id="Toe_Great" title="" points="157,615,152,618,146,619,148,603,156,603,159,609" /><polygon id="Toe_Great" title="" points="162,616,166,620,172,619,175,613,172,609,171,603,161,603" /><polygon id="Toe_s_" title="" points="177,619,191,619,197,617,201,614,200,609,193,606,186,601,172,603" /><polygon id="Foot" title="" points="185,595,160,594,161,602,187,601" /><polygon id="Knee_s_" title="" points="163,488,202,489,199,474,196,459,198,444,196,438,155,435,118,438,121,456,120,467,117,483,151,487,158,465,160,460,161,476,166,482" /><polygon id="Leg_Upper" title="" points="216,313,217,342,215,360,211,387,206,409,197,436,118,437,110,418,103,398,99,372,98,345,97,321,97,314,97,306,102,284,104,281,209,282,213,295" /><polygon id="Knee_s_" title="" points="561,450,562,459,559,468,596,469,599,461,603,470,640,468,640,459,639,451,640,442,620,440,587,440,559,442" /><polygon id="Neck_Soft_Tissue" title="" points="573,72,620,72,618,79,617,85,618,91,622,99,571,98,575,90,575,80" /><polygon id="Shoulder_s_" title="" points="563,104,571,98,581,109,554,124,532,152,511,159,512,148,514,136,518,127,525,120,540,112,552,108" /><polygon id="Shoulder_s_" title="" points="622,100,635,108,648,113,660,116,668,120,676,128,681,139,684,151,684,161,682,168,661,157,640,125,612,110" /><polygon id="Back_Upper" title="" points="649,188,653,166,660,156,640,125,612,109,622,99,571,98,581,109,554,124,532,152,543,165,545,178,545,200,542,216,547,222,551,238,645,239,646,228,651,218,652,210,650,200" /><polygon id="Elbow_s_" title="" points="657,252,656,245,656,236,654,224,686,214,688,219,692,227,697,235,697,244,659,260" /><polygon id="Hip" title="" points="655,381,654,391,637,387,629,361,630,341,650,337,658,325,659,343,656,365" /><polygon id="Buttocks" title="" points="621,343,612,343,605,339,599,333,594,337,587,341,580,341,572,341,554,337,538,329,538,320,539,311,543,293,654,293,658,323,649,337,632,341" /><polygon id="Leg_Upper" title="" points="588,341,562,340,556,386,541,390,543,400,549,420,557,436,559,441,599,439,641,441,644,433,647,421,652,404,654,391,637,387,629,361,629,342,618,343,606,340,599,333,594,337" /><polygon id="Elbow_s_" title="" points="540,231,510,220,508,223,505,228,499,236,498,245,538,255,541,248,542,239" /><polygon id="Leg_Lower" title="" points="555,525,561,545,570,569,577,591,601,592,626,591,629,580,633,561,641,533,645,515,646,497,644,481,640,468,603,470,604,484,602,496,602,521,605,549,604,578,601,594,595,571,596,534,597,519,598,501,595,490,596,468,559,469,553,495,553,514" /><polygon id="Ankle" title="" points="596,602,571,600,575,592,599,592,626,591,626,591,627,601,604,602,599,593" /><polygon id="Foot" title="" points="608,619,602,615,602,609,605,602,626,602,631,606,638,609,640,615,630,619,617,620" /><polygon id="Foot" title="" points="562,619,579,620,596,617,597,612,595,607,596,602,572,599,567,609,563,610,557,614" /><polygon id="Arm_Upper" title="" points="532,152,543,165,544,178,544,200,541,215,540,230,510,219,509,200,512,186,513,178,512,168,512,159" /><polygon id="Arm_Upper" title="" points="661,157,681,168,681,176,685,185,685,203,685,214,654,224,652,210,650,200,649,188,653,166" /><polygon id="Arm_Lower" title="" points="704,270,702,253,698,244,659,261,663,271,666,279,670,285,675,291,678,297,684,306,691,315,717,305,709,286" /><polygon id="Wrist" title="" points="718,306,692,316,696,324,721,317" /><polygon id="Hand" title="" points="696,324,721,317,730,323,735,329,726,329,730,341,697,345,694,333" /><polygon id="Finger_s_" title="" points="697,346,731,341,733,363,732,374,729,382,725,384,720,387,714,385,709,383,708,378,702,374,699,365" /><polygon id="Thumb" title="" points="727,330,736,329,739,336,746,348,743,351,739,350,730,340" /><polygon id="Thumb" title="" points="460,336,469,334,466,343,460,354,453,354,452,350,456,344" /><polygon id="Arm_Lower" title="" points="484,307,505,319,510,313,521,292,532,274,538,255,497,245,497,246,495,251,493,260,490,276,486,291,483,301" /><polygon id="Hand" title="" points="486,347,468,350,467,344,469,334,460,336,462,331,467,326,474,323,478,317,500,327,503,338,502,351" /><polygon id="Wrist" title="" points="484,308,505,319,501,328,478,316" /><polygon id="Finger_s_" title="" points="467,351,467,367,468,372,466,380,470,385,478,387,486,385,491,373,496,373,498,366,499,358,502,351,486,347" /><polygon id="Head_Soft_Tissue" title="" points="123,40,184,40,185,47,187,53,186,59,183,65,179,69,176,77,174,83,169,88,162,93,153,93,143,90,135,83,132,75,127,69,122,59,121,52,123,49" /><polygon id="Head_Soft_Tissue" title="" points="571,68,564,63,562,57,563,50,565,43,565,35,569,26,575,19,582,15,590,13,603,13,610,16,616,20,621,26,626,34,627,40,625,46,629,49,629,57,627,62,623,68,620,72,573,71" /></svg>
</div>
				</div>

			</div>


			</div>

		<!-- reportcontainer -->
			<div class="col col-sm-12 col-md-12 col-lg-6" id="reportholder" style="padding:0px;">
			<div ng-view></div>
		
				
			</div>

		<!-- search and list container -->
			<div class="col col-sm-12 col-md-12 col-lg-2  w3-animate-right" id="listholder" style="padding:0px">
				 <div class="input-group">
    <span class="input-group-addon" style="background-color:#d9dfe1;outline:none;border:0px solid #fff"><i class="glyphicon glyphicon-search"></i></span>
    <input id="searchtext" ng-model="searchtext" type="text" class="form-control" name="Search" placeholder="Search" id="filtered" style="background-color:#d9dfe1;outline:none;border:0px solid #fff">
  </div>
  <br/>
  <span><b style="margin-left:15px;color:#a0a0a0">RECENT REPORTS</b></span>


				<ul class="list-group">
						<li class="list-group-item" style='background-color:transparent'>
					<a href="/#/">
					<div class="push-left">
						
							<span><img src="img/test.png" style="width:40px;height:40px;border-radius:20px	"/>  <a href="#/"  ><b>Dashboard</b></a>
                         	  <h6 class="text-muted time" style="margin-left:45px;margin-top:-5px">Dashboard</h6>
                         </span>
					 </div>

					</a>
					</li>
	
						<li class="list-group-item" style='background-color:transparent' ng-repeat="report in reports |filter :searchtext">
					<a href="/#/reports/{{$index}}">
					<div class="push-left">
						
							<span><img src="img/test.png" style="width:40px;height:40px;border-radius:20px	"/>  <a href="#/reports/{{$index}}" ng-click="generateReport($index,report.reportName,report.timestamp)" ><b>{{report.reportName}}</b></a>
                         	  <h6 class="text-muted time" style="margin-left:45px;margin-top:-5px">{{report.timestamp | datefilter}}</h6>
                         </span>
					 </div>

					</a>
					</li>

						
  
</ul>

			</div>

		</div>


</div>

  <script type="text/javascript">
 
  document.onreadystatechange = function(e)
{
    if (document.readyState === 'complete')
    {
        //dom is ready, window.onload fires later
        	$.ajax({
  		method:"post",
  		url:"json/latestresponse.json",
  		success:function(){
  			//REPORT DATA
  			console.log(arguments[0].testDetails);
  			var reportlist=[];
  			var yearsarray=Object.keys(arguments[0].testDetails);
  			for(i=0;i<yearsarray.length;i++)
  			{
  				var currentobj=Object.keys(arguments[0].testDetails[yearsarray[i]]);
  				console.log(currentobj);
  				for(j=0;j<currentobj.length;j++)
  				{
  					reportlist.push({year:yearsarray[i],reportName:currentobj[j],observations:arguments[0].testDetails[yearsarray[i]][currentobj[j]],timestamp:arguments[0].testDetails[yearsarray[i]][currentobj[j]][0].timeStamp});
  				}
  			}
  			console.log(reportlist);
  			window.reportData=reportlist;
  			
  		},
  		error:function(){
  			console.log(arguments[0]);
  		}
  	});
    }
};
 window.document.onload=function(){

  		console.log("***********"); 
  		console.log(window.reportData);



  }

var app=angular.module("reportDash",["ngRoute"]);
app.filter("datefilter",function(){
	
	return function(dataval){
		var dts=dataval.toString();
		return dts.substring(0,4)+"/"+dts.substring(4,6)+"/"+dts.substring(6,8);
	}
});
app.config(function($routeProvider){
	$routeProvider.when("/",{
		templateUrl:"partials/default.html"
	}).when("/reports/:id",{
		templateUrl:"partials/report.html"
	});
});
app.controller("maincontroller",['$scope','$window',function($scope,$window){

	
	console.log($window);

	
	setTimeout(function () {
        $scope.$apply(function () {
           $scope.reports=$window.reportData;
        });
    }, 2000);
	console.log("@@@@@@@@");
	console.log($scope.reports);

	$scope.checkAlert=function(rowobj)
	{
		console.log(rowobj);
		alert();
		return "ok";
	}
	$scope.generateReport=function(mark,repname,timestamped)
	{
		$scope.repname=repname;
		$scope.reportTime=timestamped;
		//alert(mark);
		console.log($scope.reports[mark]);
		console.log($scope.reports[mark].observations);
		$scope.observationarray=$scope.reports[mark].observations;
		$scope.reportarray=[];
		$scope.abnormality=[];
		for(k=0;k<$scope.observationarray.length;k++)
		{
			var observationsubkeyarray=Object.keys($scope.observationarray[k].observationDetails);
			var observationobj=JSON.parse($scope.observationarray[k].observationDetails[observationsubkeyarray[0]]);
			console.log(observationobj);
			console.log(observationsubkeyarray);
			 $scope.reportarray.push({
				label:observationobj.Observation_identifier.Observation_Text,
				range:observationobj.Result_unit_reference_range,
				value:observationobj.Observation_value,
				unit:observationobj.Result_units_of_measurement,
				abnormal:observationobj.Abnormal_flags
			});
			 console.log($scope.reportarray);
			 if(observationobj.Abnormal_flags=="H")
			 {
			 		$scope.abnormality.push({lbl:observationobj.Observation_identifier.Observation_Text,txt:" is above normal :"+observationobj.Observation_value +" | ("+observationobj.Result_unit_reference_range+")",indicator:"glyphicon glyphicon-upload"});
			 }
			  if(observationobj.Abnormal_flags=="L")
			 {
			 		$scope.abnormality.push({lbl:observationobj.Observation_identifier.Observation_Text,txt:" is below normal :"+observationobj.Observation_value +" | ("+observationobj.Result_unit_reference_range+")",indicator:"glyphicon glyphicon-download"});
			 }
		}
		console.log($scope.abnormality);
		$scope.modalheader=event.target.innerText;
			


	}

}]);

  </script>
</body>
</html>