<html lang="en" >
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Angular Material style sheet -->
  <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/angular_material/1.1.0/angular-material.min.css">
  <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
 
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script type="text/javascript">
 window.onload=  function checkCall()
 {
  
  $.ajax({
    method:"GET",
    url:"http://localhost:8080/Arogya/ArogyaServer?customer=199999999",
   //url:'json/finalresponse.json',
    success:function(resp){
  
      window.localStorage.setItem("finalResponse",JSON.stringify(resp));
       

    }
  });
 };


  </script>
  <style type="text/css">
.header_row
{
  
}

  </style>
</head>
<body ng-app="dashboardApp" ng-cloak ng-controller="dashboardController as dash">
  <!--
    Your HTML content here
  -->  


 <md-sidenav class="md-sidenav-left" md-component-id="left"
                md-disable-backdrop md-whiteframe="4" style="height:100%;z-index:5000;width:25%;background-color:#1c2331">

      <md-toolbar class="md-theme-indigo" style="height:100px;background-color:#1de9b6">
        <span class="md-toolbar-tools" style="font-size:30px;margin-top:10px">Reports</span>
      </md-toolbar>

      <md-content layout-margin style="background-color:#1c2331;color:#fff">
        <p>
          <ul id="reports">
    <li class="listelement" ng-click="switchedTab(1)"><i class="fa  fa-chevron-circle-right"></i> &nbsp Blood Report</li>
    <li class="listelement" ng-click="switchedTab(1)"><i class="fa  fa-chevron-circle-right" ></i> &nbsp Urine</li>
    <li class="listelement" ng-click="switchedTab(1)"><i class="fa  fa-chevron-circle-right"></i> &nbsp Ear Checl</li>
    <li class="listelement" ng-click="switchedTab(1)"><i class="fa  fa-chevron-circle-right"></i> &nbsp Cholestrol Level</li>

  </ul>
        </p>
        <md-button class="md-raised md-primary" ng-click="toggleLeft()" class="md-accent" style="padding-left:10px;padding-right:10px">
          BACK
        </md-button>
      </md-content>

    </md-sidenav>
   
  <?php include 'views/toolbar.php' ?>
  <div  layout="row" flex>
  <?php include 'views/sidenav.php' ?>
  <?php include 'views/rightpanel.php' ?>
  </div>>
  
  <!-- Angular Material requires Angular.js Libraries -->
  <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular.min.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-animate.min.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-aria.min.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular-messages.min.js"></script>

  <!-- Angular Material Library -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/angular-material/1.1.4/angular-material.min.js"></script>
  <script type="text/javascript" src="app.js"></script>
  <script type="text/javascript" src="services/utilityServices.js"></script>
  <script type="text/javascript" src="services/reportService.js"></script>

  <script type="text/javascript" src="controllers/dashboardController.js"></script>

  <script type="text/javascript" src="controllers/toolbarController.js"></script>
  <script type="text/javascript" src="controllers/summaryController.js"></script>
 <script type="text/javascript" src="controllers/profileController.js"></script>
   <script type="text/javascript" src="controllers/reportController.js"></script>
  <script type="text/javascript" src="controllers/PanelProviderCtrl.js"></script>


<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
<script src="node_modules/angular-chart.js/dist/angular-chart.min.js"></script>
<script type="text/javascript" src="angular-fusioncharts.min.js"></script>
<script type="text/javascript">
var a='{"data":{"msg":"success","userData":"{  \r\n   \"customerid\":\"P0000665544\",\r\n   \"reportlist\":[  \r\n      \"\\\"Diabetes\\\":{\\\"Timestamp\\\": \\\"20090518161040\\\",\\\"Blood Glucose\\/Sugar Fasting\\\": 12.2,\\\"Microalbumin Screen\\\": 10.4,\\\"Urine Glucose\\\": 18.3,\\\"HbA1c\\\": 37,\\\"Average Glucose (For last 60-90 days)\\\": 12,\\\"Amylase\\\": 65,\\\"Urine Creatinine\\\": 4.34,\\\"Urine Microalbumin Creatinine Ratio\\\": 19.4}\",\r\n      \"\\\"Urine\\\":{\\\"Timestamp\\\": \\\"20100518161040\\\",\\\"Urobilinogen\\\": 100,\\\"Bilirubin\\\": 10.3,\\\"Ketone\\\": 133,\\\"Blood\\\": 2,\\\"Protein\\\": 10.3,\\\"Nitrite\\\": 20,\\\"Leucocytes\\\": 34,\\\"Colour\\\": \\\" PALE YELLOW\\\",\\\"Appearance\\\": \\\"YELLOW \\\",\\\"Specific Gravity\\\": 20.4,\\\"Reaction pH\\\": 3.45,\\\"PUS Cell\\\": 8.3,\\\"Epithelial Cell\\\": 333,\\\"Casts\\\": 234,\\\"Crystals\\\": 54,\\\"Bacteria\\\": \\\"NO\\\",\\\"RBCS\\\": 765,\\\"Calcium\\\": 539,\\\"Ascorbic acid\\\": 23,\\\"Bile Salts\\\": 9.85,\\\"Bile Pigments\\\": 4.83}\",\r\n      \"\\\"BloodTest\\\":{\\\"Timestamp\\\": \\\"201105181613423\\\",\\\"Total Leucocyte\\\": 100,\\\"Neutrophil Count\\\": 240,\\\"Absolute Neutrophil Count\\\": 323,\\\"Lymphocyte Count\\\": 654,\\\"Absolute Lymphocyte Count\\\": 23,\\\"Eosinophil Count\\\": 273,\\\"Absolute Eosinophil Count\\\":345,\\\"Monocyte Count\\\": 657,\\\"Absolute Monocyte Count\\\": 98,\\\"Basophill Count\\\": 372,\\\"Absolute Basophill Count\\\": 56,\\\"Platelet Count\\\": 435,\\\"Platelet Distribuiter Width\\\": 45,\\\"Platelet Large Cell Volume\\\": 345,\\\"Mean Platelet Volume\\\": 76,\\\"PCT\\\": 769,\\\"Large Unstained Cell\\\": 786}\",\r\n      \"\\\"HeartCheckUp\\\":{\\\"Timestamp\\\": \\\"20120518123224\\\",\\\"APOLIPOPROTEIN-A\\\": 685,\\\"APOLIPOPROTEIN-B1\\\": 70,\\\"Creatine Kinase\\\": 446,\\\"Total Cholesterol\\\": 757,\\\"Triglycerides\\\": 55,\\\"High Density Lipoprotein Good Cholesterol\\\": 989,\\\"Low Density Lipoprotein Bad Cholesterol\\\": 489,\\\"Very Low Density Lipoprotein Cholesterol\\\": 456,\\\"Total Cholesterol \\/ HDL Cholesterol Ratio\\\": 459,\\\"LDL \\/ HDL Ratio\\\": 46,\\n\\\"APO A : APO B\\\": 76}\",\r\n      \"\\\"AnemiaScreen\\\":{\\\"Timestamp\\\": \\\"20130723094256\\\",\\\"Iron (Fe)\\\": 23,\\\"Hemoglobin (Hb)\\\": 657,\\\"Red Blood Cell Counts (RBC)\\\": 456,\\\"RBC Distribution Width (RDW-CV)\\\": 699,\\\"RBC Distribution Width (RDW-SD)\\\": 457,\\\"Mean Corpuscular Volume (MCV)\\\": 46,\\\"Mean Corpuscular Hemoglobin (MCH)\\\": 479,\\\"Mean Corpuscular Hb Concentration (MCHC)\\\": 78,\\\"Haematocrit \\/ PCV \\/ HCT\\\": 588,\\\"Transferrin\\\": 6.89,\\\"% saturation\\\": 67.8,\\\"Total Iron Binding Capacity (TIBC)\\\": 76,\\\"Unsaturated Iron-Binding Capacity (UIBC)\\\": 678,\\\"Content Hemoglobin\\\": 59}\"\r\n   ],\r\n   \"BasicDetails\":{\"customerid\": \"P0000987654\",\r\n  \"Name\":\"Sameer Mathur\",\r\n  \"Age\":36,\r\n  \"Contanct\":\"8843531232\",\r\n  \"Address\":\"B-101 Diamond Street ,KempaGauda\",\r\n  \"City\": \"Hyderabad\",\r\n  \"State\": \"Andhra Pradesh\",\r\n  \"Country\": \"India\",\r\n   \"Gender\": \"M\"\r\n  \r\n\r\n  \r\n  }\r\n}"},"status":200,"config":{"method":"POST","transformRequest":[null],"transformResponse":[null],"jsonpCallbackParam":"callback","url":"http://localhost:3000/authentication","headers":{"Content-Type":"application/json","Accept":"application/json, text/plain, */*"},"data":"{\"user\":\"himanshumishra1234@gmail.com\",\"enteredpass\":\"admin\"}"},"statusText":"OK"}';
window.localStorage.setItem("profiledData",JSON.stringify(a));


var barData = {
    labels: ['Italy', 'UK', 'USA', 'Germany', 'France', 'Japan'],
    datasets: [
        {
            label: '2010 customers #',
            fillColor: '#382765',
            data: [2500, 1902, 1041, 610, 1245, 952]
        },
        {
            label: '2014 customers #',
            fillColor: '#7BC225',
            data: [3104, 1689, 1318, 589, 1199, 1436]
        }
    ]
};
var context = document.getElementById('clients').getContext('2d');
var clientsChart = new Chart(context).Bar(barData);


</script>
<style type="text/css">
.listelement{

  height:25px;
  padding:6px;
  margin-left:-20px;
  pointer:cursor;
  outline:none;



 
</style>


</body>
</html>