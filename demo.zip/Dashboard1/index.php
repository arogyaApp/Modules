<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>Arogya</title>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">

    <!-- Your custom styles (optional) -->
    <link href="css/style.css" rel="stylesheet">
     <link href="style.css" rel="stylesheet">
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.6.1/angular.min.js"></script>
     <script type="text/javascript" src="angiworld/logincontroller.js"></script>
</head>

<body ng-app="arogya">


  
    <?php include 'snippets/navigation.php' ?>
    <?php include 'snippets/login.php' ?>

    <!--Main container-->
    <div class="container">

        <div class="divider-new">
            <h2 class="h2-responsive wow fadeInDown">Tips & Features</h2>
        </div>

         
         <?php include 'snippets/best_features.php' ?>

        <div class="divider-new">
            <h2 class="h2-responsive wow fadeInDown">Additional Features</h2>
        </div>

       

    </div>
    <!--/Main container-->

    <!--Footer-->
    <footer class="page-footer center-on-small-only">


    </footer>
    <!--/.Footer-->


    <!-- SCRIPTS -->

    <!-- JQuery -->
    <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>

    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="js/tether.min.js"></script>

    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <script type="text/javascript">
            new WOW().init();

var a='{"data":{"msg":"success","userData":"{  \r\n   \"customerid\":\"P0000665544\",\r\n   \"reportlist\":[  \r\n      \"\\\"Diabetes\\\":{\\\"Timestamp\\\": \\\"20090518161040\\\",\\\"Blood Glucose\\/Sugar Fasting\\\": 12.2,\\\"Microalbumin Screen\\\": 10.4,\\\"Urine Glucose\\\": 18.3,\\\"HbA1c\\\": 37,\\\"Average Glucose (For last 60-90 days)\\\": 12,\\\"Amylase\\\": 65,\\\"Urine Creatinine\\\": 4.34,\\\"Urine Microalbumin Creatinine Ratio\\\": 19.4}\",\r\n      \"\\\"Urine\\\":{\\\"Timestamp\\\": \\\"20100518161040\\\",\\\"Urobilinogen\\\": 100,\\\"Bilirubin\\\": 10.3,\\\"Ketone\\\": 133,\\\"Blood\\\": 2,\\\"Protein\\\": 10.3,\\\"Nitrite\\\": 20,\\\"Leucocytes\\\": 34,\\\"Colour\\\": \\\" PALE YELLOW\\\",\\\"Appearance\\\": \\\"YELLOW \\\",\\\"Specific Gravity\\\": 20.4,\\\"Reaction pH\\\": 3.45,\\\"PUS Cell\\\": 8.3,\\\"Epithelial Cell\\\": 333,\\\"Casts\\\": 234,\\\"Crystals\\\": 54,\\\"Bacteria\\\": \\\"NO\\\",\\\"RBCS\\\": 765,\\\"Calcium\\\": 539,\\\"Ascorbic acid\\\": 23,\\\"Bile Salts\\\": 9.85,\\\"Bile Pigments\\\": 4.83}\",\r\n      \"\\\"BloodTest\\\":{\\\"Timestamp\\\": \\\"201105181613423\\\",\\\"Total Leucocyte\\\": 100,\\\"Neutrophil Count\\\": 240,\\\"Absolute Neutrophil Count\\\": 323,\\\"Lymphocyte Count\\\": 654,\\\"Absolute Lymphocyte Count\\\": 23,\\\"Eosinophil Count\\\": 273,\\\"Absolute Eosinophil Count\\\":345,\\\"Monocyte Count\\\": 657,\\\"Absolute Monocyte Count\\\": 98,\\\"Basophill Count\\\": 372,\\\"Absolute Basophill Count\\\": 56,\\\"Platelet Count\\\": 435,\\\"Platelet Distribuiter Width\\\": 45,\\\"Platelet Large Cell Volume\\\": 345,\\\"Mean Platelet Volume\\\": 76,\\\"PCT\\\": 769,\\\"Large Unstained Cell\\\": 786}\",\r\n      \"\\\"HeartCheckUp\\\":{\\\"Timestamp\\\": \\\"20120518123224\\\",\\\"APOLIPOPROTEIN-A\\\": 685,\\\"APOLIPOPROTEIN-B1\\\": 70,\\\"Creatine Kinase\\\": 446,\\\"Total Cholesterol\\\": 757,\\\"Triglycerides\\\": 55,\\\"High Density Lipoprotein Good Cholesterol\\\": 989,\\\"Low Density Lipoprotein Bad Cholesterol\\\": 489,\\\"Very Low Density Lipoprotein Cholesterol\\\": 456,\\\"Total Cholesterol \\/ HDL Cholesterol Ratio\\\": 459,\\\"LDL \\/ HDL Ratio\\\": 46,\\n\\\"APO A : APO B\\\": 76}\",\r\n      \"\\\"AnemiaScreen\\\":{\\\"Timestamp\\\": \\\"20130723094256\\\",\\\"Iron (Fe)\\\": 23,\\\"Hemoglobin (Hb)\\\": 657,\\\"Red Blood Cell Counts (RBC)\\\": 456,\\\"RBC Distribution Width (RDW-CV)\\\": 699,\\\"RBC Distribution Width (RDW-SD)\\\": 457,\\\"Mean Corpuscular Volume (MCV)\\\": 46,\\\"Mean Corpuscular Hemoglobin (MCH)\\\": 479,\\\"Mean Corpuscular Hb Concentration (MCHC)\\\": 78,\\\"Haematocrit \\/ PCV \\/ HCT\\\": 588,\\\"Transferrin\\\": 6.89,\\\"% saturation\\\": 67.8,\\\"Total Iron Binding Capacity (TIBC)\\\": 76,\\\"Unsaturated Iron-Binding Capacity (UIBC)\\\": 678,\\\"Content Hemoglobin\\\": 59}\"\r\n   ],\r\n   \"BasicDetails\":{\"customerid\": \"P0000987654\",\r\n  \"Name\":\"Sameer Mathur\",\r\n  \"Age\":36,\r\n  \"Contanct\":\"8843531232\",\r\n  \"Address\":\"B-101 Diamond Street ,KempaGauda\",\r\n  \"City\": \"Hyderabad\",\r\n  \"State\": \"Andhra Pradesh\",\r\n  \"Country\": \"India\",\r\n   \"Gender\": \"M\"\r\n  \r\n\r\n  \r\n  }\r\n}"},"status":200,"config":{"method":"POST","transformRequest":[null],"transformResponse":[null],"jsonpCallbackParam":"callback","url":"http://localhost:3000/authentication","headers":{"Content-Type":"application/json","Accept":"application/json, text/plain, */*"},"data":"{\"user\":\"himanshumishra1234@gmail.com\",\"enteredpass\":\"admin\"}"},"statusText":"OK"}';
window.localStorage.setItem("profiledData",JSON.stringify(a));

    </script>


</body>

</html>