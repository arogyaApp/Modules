var arogya=angular.module("arogya",[]);
alert();

arogya.controller("logincontroller",['$scope','$http','$window',function($scope,$http,$window){
	
$scope.name="";
$scope.password="";
$scope.isOTP=false;
$scope.isError=false;
$scope.ajaxcaller=function(url,params,method){
	var returnedmsg;
		if(method=="POST")
		{
			var callparams={
				method:"POST",
				data:params,
				url:url,
				'Content-Type':'application/json'
			};
			
		}
		else
		{
			var callparams={
				method:"GET",
				url:url,
				'Content-Type':'application/json'
			}
		}
		$http(callparams).then(function(response){
			//successcallback
			var retmsg={type:"success",resp:response};
			return retmsg;

		},function(){
			//errorcallback
			var retmsg={type:"error",resp:arguments};


		});
};




$scope.login=function(){
	
	$http({
		url:"http://localhost:3000/authentication",
		method:"POST",
		headers: {
 			  'Content-Type': "application/json"

 		},
		data:JSON.stringify({user:$scope.name,enteredpass:$scope.password})

	}).then(function(response){
		//success callback
		console.log(response);
		console.log(response.valid);
		if(response.data.msg=="success")
		{

				window.localStorage.setItem("profileData",JSON.stringify(response));
				window.location.replace("dashboard.php");
		}
		else
		{
				$scope.errorMsg=response.data.msg;
				$scope.isError=true;
		}

	},function(){
		//error handler
		console.log(arguments);

	});

}



}]);