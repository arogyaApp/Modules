	<div class="col col-sm-12 col-md-12 col-lg-2" id="listholder" style="padding:0px">
				 <div class="input-group">
    <span class="input-group-addon" style="background-color:#d9dfe1;outline:none;border:0px solid #fff"><i class="glyphicon glyphicon-search"></i></span>
    <input id="filter" ng-model="searchkey" type="text" class="form-control" name="Search" placeholder="Search" id="filtered" style="background-color:#d9dfe1;outline:none;border:0px solid #fff">
  </div>
  <br/>
  <span><b style="margin-left:15px;color:#a0a0a0">RECENT REPORTS</b></span>
				<ul class="list-group">
						<li class="list-group-item" style='background-color:transparent' class="rotate-in">
					<a href="/#/">
					<div class="push-left">
						
							<span><img src="" style="width:40px;height:40px;border-radius:20px	"/>  <a href="#/"  ><b>Dashboard</b></a>
                         	  <h6 class="text-muted time" style="margin-left:45px;margin-top:-5px">Dashboard</h6>
                         </span>
					 </div>

					</a>
					</li>
	
						<li class="w3-container  w3-animate-zoom list-group-item" style='background-color:transparent;' ng-repeat="report in reports | filter:searchkey">
					<a href="/#/reports/{{$index}}">
					<div class="push-left">
						
							<span><i class="glyphicon glyphicon-file" style="width:40px;height:40px;color:#2f96e9;border-radius:20px;font-size:32px"></i> <a href="#/reports/{{$index}}" ng-click="generateReport($index)" ><b style="">{{report.reportName}}</b></a>
                         	  <h6 class="text-muted time" style="margin-left:45px;margin-top:-5px">{{report.timestamp}}</h6>
                         </span>
					 </div>

					</a>
					</li>

						
  
</ul>

			</div>