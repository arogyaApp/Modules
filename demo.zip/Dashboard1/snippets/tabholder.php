	<div class="col col-sm-12 col-md-12 col-lg-1" id="tabholder">
				
				<div class="row">
						<div class="col col-12">
								<div class="well btnholder">
									<h3><i class="glyphicon glyphicon-list" style="color:#fff"></i></h3>
								</div>
						</div>
						<div class="col col-12">
								<div class="well btnholder">
									<h3><i class="glyphicon glyphicon-user" style="color:#fff" data-toggle="modal" data-target="#myModal"></i></h3>
								</div>
						</div>
						<div class="col col-12">
								<div class="well btnholder">
									<h3><i class="glyphicon glyphicon-time" style="color:#fff"></i></h3>
								</div>
						</div>
						<div class="col col-12">
								<div class="well btnholder">
									<h3><i class="glyphicon glyphicon-list" style="color:#fff"></i></h3>
								</div>
						</div>
						



				</div>



			</div>