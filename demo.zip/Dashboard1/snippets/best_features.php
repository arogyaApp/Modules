<!--Section: Best features-->
        <section id="best-features">
            <div class="row">
                <!--First columnn-->
                <div class="col-md-4">
                         <!--Card-->
            <div class="card wow fadeInUp">

                <!--Card image-->
                <div class="view overlay hm-white-slight">
                    <img src="img/tiles.jpg" class="img-fluid" alt="">
                    <a href="#">
                        <div class="mask waves-light"></div>
                    </a>
                </div>
                <!--/.Card image-->

                <!--Card content-->
                <div class="card-block text-center">
                    <!--Title-->
                    <h4 class="card-title">Mind-Body, Body-Mind!</h4>
                    <hr>
                    <!--Text-->
                    <p class="card-text">Here are some simple facts to learn about the Mind-Body Connection:Our brain is made up of chemicals called neurotransmitters that.</p>
                </div>
                <!--/.Card content-->

            </div>
            <!--card -->
                </div>
                <!--First columnn-->

                <!--Second columnn-->
                <div class="col-md-4">
                         <!--Card-->
            <div class="card wow fadeInUp">

                <!--Card image-->
                <div class="view overlay hm-white-slight">
                    <img src="img/tiles2.jpg" class="img-fluid" alt="">
                    <a href="#">
                        <div class="mask waves-light"></div>
                    </a>
                </div>
                <!--/.Card image-->

                <!--Card content-->
                <div class="card-block text-center">
                    <!--Title-->
                    <h4 class="card-title">30 power moves with just a yoga mat</h4>
                    <hr>
                    <!--Text-->
                    <p class="card-text">Armed with just a yoga mat and some determination, here are 30 powerful fitness moves you can do without even stepping </p>
                </div>
                <!--/.Card content-->

            </div>
                </div>
                <!--Second columnn-->

                <!--Third columnn-->
                <div class="col-md-4">
                         <!--Card-->
            <div class="card wow fadeInUp">

                <!--Card image-->
                <div class="view overlay hm-white-slight">
                    <img src="img/tiles3.jpg" class="img-fluid" alt="">
                    <a href="#">
                        <div class="mask waves-light"></div>
                    </a>
                </div>
                <!--/.Card image-->

                <!--Card content-->
                <div class="card-block text-center">
                    <!--Title-->
                    <h4 class="card-title">Eight reasons to buy health insurance</h4>
                    <hr>
                    <!--Text-->
                    <p class="card-text">Health Insurance is necessary for every individual, keeping in mind the rising medical costs and spurt of lifestyle</p>
                </div>
                <!--/.Card content-->

            </div>
                </div>
                <!--Third columnn-->
            </div>
        </section>
        <!--/Section: Best features-->