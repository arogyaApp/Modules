	<div class="row" style="padding-left:5px;padding-right:5px;padding-top:5px ;padding-bottom:1px">
									


									<div class="col col-md-6 stats">

										<div class="well infocard">

												<div id="container2" style="min-width: 310px; max-width: 400px; height: 240px; margin: 0 auto"></div>
										
										
										</div>
									</div>

										<div class="col col-md-6 stats">

										<div class="well infocard">
											
											 <div id="container" style="width: 200px; height: 200px; margin: 0 auto"></div>	<br/><br/>								
											 	
										</div>


									</div>

									



								</div>