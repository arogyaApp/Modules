

<div class="row" style="padding-left:5px;padding-right:30px;padding-top:5px ;padding-bottom:1px" style="height:400px">
	<div class="col col-md-6 stats">
		<div class="well infocard">

    <div class="card-header primary-color-dark white-text">
        Timelapse of Heart Beat
    </div>
    <div class="card-block" style="padding:0px">



      	<nav class="navbar ">
      		<div class="row">
      			<div class="col col-md-6">
      				<label>Start Date</label>
		<input type="date" name="startDate" style="width:50%"></input>
				</div>
				<div class="col col-md-6">
					<label>End Date</label>
		<input type="date" name="startDate" style="width:50%"></input>
				</div>
	
	</nav>

	<div id="linecontainer" style="height:180px"></div>


    </div>
</div>

		

	</div>

	<div class="col col-md-6 stats">

		<div class="well infocard" style="overflow:scroll">
		<div class="card-header primary-color-dark white-text">
        Doctor's Comments and Recommendation


    </div>
    <div class="container">
    <div class="row">
		<div class="col-md-12 col-md-offset-12 col-sm-12 col-sm-offset-12 col-xs-8 col-xs-offset-2">
        
            <!-- Fluid width widget -->        
    	    <div class="panel panel-default">
                <div class="panel-heading">
                    <h5 class="panel-title"><br/>
                        <span class="glyphicon glyphicon-comment"></span> 
                        Recent Comments
                    </h5>
                </div>
                <div class="panel-body">
                    <ul class="media-list">
                        <li class="media">
                            <div class="media-left">
                                <img src="https://mdbootstrap.com/img/Photos/Avatars/img%20%2820%29.jpg" class="rounded-circle img-fluid" style="width:80px;height:80px">
                            </div>
                            <div class="media-body">
                                <h5 class="media-heading">
                                    Mauris Eu
                                    <br>
                                    <small>
                                        commented on Ref
                                    </small>
                                </h5>
                                <p>
                                   Observed pain in Right arm . Recommended X-Ray
                                </p>
                            </div>
                        </li>
                        <li class="media">
                            <div class="media-left">
                                <img src="https://mdbootstrap.com/img/Photos/Avatars/img%20%2820%29.jpg" style="width:70px;height:70px" class="rounded-circle img-fluid">
                            </div>
                            <div class="media-body">
                                <h5 class="media-heading">
                                    Aenean Consect
                                    <br>
                                    <small>
                                        commented on 
                                    </small>
                                </h5>
                                <p>
                                   X-Ray taken for the patient .Observed hair crack on Right...
                                </p>
                            </div>
                        </li>
                        <li class="media">
                            <div class="media-left">
                               <img src="http://placehold.it/60x60" class="img-circle">
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading">
                                    Praesent Tinci
                                    <br>
                                    <small>
                                        commented on <a href="#">Post Title</a>
                                    </small>
                                </h4>
                                <p>
                                    Sed convallis dignissim magna et dignissim. Praesent tincidunt sapien eu gravida dignissim.
                                </p>
                            </div>
                        </li>
                    </ul>
                    <a href="#" class="btn btn-default btn-block">More Events »</a>
                </div>
            </div>
            <!-- End fluid width widget --> 
            
		</div>
	</div>
</div>


</div>


	</div>




</div>
