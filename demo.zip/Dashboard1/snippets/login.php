   <!--Mask-->
    <div class="view hm-black-strong" ng-controller="logincontroller">
        <div class="full-bg-img flex-center">
            <div class="container">
                <div class="row" id="home">

                    <!--First column-->
                    <div class="col-lg-7">
                              <div class="description">
        <h2 class="h2-responsive wow fadeInLeft">Arogya</h2>
        <hr class="hr-dark">
        <p class="wow fadeInLeft" data-wow-delay="0.4s">The main aim of Arogya  is to create an open and secure repository of all the data related to a Person’s Health. It will be a consortium of Health records and Arogya will make it easily available on demand. It is a deep health tracker, which will enable patients to go beyond tracking steps and weights. Users would be able to authorize and share their reports to relevant people, doctors for specified duration</p>
        <br>
        <a class="btn btn-primary wow fadeInLeft" href="register" data-wow-delay="0.7s">Register</a>
    </div>
                    </div>
                    <!--/.First column-->

                    <!--Second column-->
                    <div class="col-lg-5">
                              <div class="card wow fadeInRight">
        <div class="card-block">
            <!--Header-->
            <div class="text-center">
                <h3><i class="fa fa-user"></i></h3>
                <span><h1>Arogya</h1></span>
            </div>

            <!--Body-->
            <div class="md-form">
                <i class="fa fa-envelope prefix"></i>
                <input type="text" id="form2" class="form-control" name="name" ng-model="name">
                <label for="form2">Email</label>
            </div>

            <div class="md-form" ng-hide="isOTP">
                <i class="fa fa-lock prefix"></i>
                <input type="password" id="form4" class="form-control" name="password" ng-model="password">
                <label for="form4">Password</label>
            </div>

            <div class="md-form" ng-show="isOTP">
                <i class="fa fa-user-secret prefix"></i>
                <input type="password" id="form4" class="form-control" name="otp" ng-model="otp" >
                <label for="form4">OTP</label>
            </div>

            <div class="text-center">
                <button class="btn btn-primary btn-lg" ng-click="login()">Login</button>
                <a href="signup.php" target="_blank" class="btn btn-primary btn-lg">REGISTER</a>
                <hr>
                <fieldset class="form-group">
                    <input type="checkbox" id="checkbox1" ng-model="isOTP">
                    <label for="checkbox" >Login with OTP</label><br/>
                    <label ng-show="isOTP">OTP is sent on your email</label>
                    <label ng-show="isError" class="btn btn-danger">{{errorMsg}}</label>
                </fieldset>
            </div>

        </div>
    </div>
                    </div>
                    <!--/Second column-->
                </div>
            </div>
        </div>
    </div>
    <!--/.Mask-->