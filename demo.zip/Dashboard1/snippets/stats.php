	<div class="row" style="margin-top:5px;padding-left:5px;padding-right:30px">
									<div class="col col-md-3 stats">

										<div class="well statscard wow fadeInUp">
											<div class="well">
									<div style="padding:20px">
										<h5>Heart Rate</h5>
										<h3>51</h3>
										
									</div>

								</div>


										</div>
									</div>

										<div class="col col-md-3 stats">

										<div class="well statscard wow fadeInUp">
											

										</div>
									</div>

									<div class="col col-md-3 stats">

										<div class="well statscard wow fadeInUp">

													<div class="well">
									<div style="padding:20px">
										<h5>ENT</h5>
										<h3>Normal</h3>
									</div>

								</div>


										</div>
									</div>

										<div class="col col-md-3 stats">

										<div class="well statscard wow fadeInUp"></div>
									</div>



								</div>


								<div class="row" style="margin-top:10px;padding-left:30px;padding-right:30px">
									<div class="col col-md-3 stats">

										<div class="well statscard wow fadeInDown">
													<div class="well">
									<div style="padding:20px">
										<h5>Liver</h5>
										<h3>Normal</h3>
									</div>

								</div>


										</div>
									</div>

										<div class="col col-md-3 stats">

										<div class="well statscard wow fadeInDown">





										</div>
									</div>

									<div class="col col-md-3 stats">

										<div class="well statscard wow fadeInDown">
															<div class="well">
									<div style="padding:20px">
										<h5>Kidney</h5>
										<h3>Normal</h3>
									</div>

								</div>



										</div>
									</div>

										<div class="col col-md-3 stats wow fadeInDown">

										<div class="well statscard"></div>
									</div>



								</div>
