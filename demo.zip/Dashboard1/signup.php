<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>Arogya</title>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">

    <!-- Your custom styles (optional) -->
    <link href="css/style.css" rel="stylesheet">
     <link href="style.css" rel="stylesheet">
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.6.1/angular.min.js"></script>
     <script type="text/javascript" src="angiworld/logincontroller.js"></script>
</head>

<body ng-app="arogya">


  
    <?php include 'snippets/navigation.php' ?>
    <?php include 'snippets/signupform.php' ?>

    <!--Main container-->
    <div class="container">

        <div class="divider-new">
            <h2 class="h2-responsive wow fadeInDown">Tips & Features</h2>
        </div>

         
         <?php include 'snippets/best_features.php' ?>

        <div class="divider-new">
            <h2 class="h2-responsive wow fadeInDown">Additional Features</h2>
        </div>

       

    </div>
    <!--/Main container-->

    <!--Footer-->
    <footer class="page-footer center-on-small-only">


    </footer>
    <!--/.Footer-->


    <!-- SCRIPTS -->

    <!-- JQuery -->
    <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>

    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="js/tether.min.js"></script>

    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <script type="text/javascript">
            new WOW().init();



    </script>


</body>

</html>