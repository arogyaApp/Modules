<!DOCTYPE html>
<html>
<head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="reportstyle.css">
 
  <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.4/Chart.min.js"></script>
<script type="text/javascript" src="https://code.angularjs.org/1.5.5/angular-route.min.js"></script>
<script type="text/javascript" src="https://code.angularjs.org/1.5.5/angular-animate.min.js"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" type="text/css">
</head>
<body ng-app="reportDash" ng-controller="maincontroller">


	<!--modal content -->
	<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog" >
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content" style="width:600;height:400px;overflow-y:scroll">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">{{modalheader}}</h4>
      </div>
      <div class="modal-body" >
        <iframe src="http://localhost/dicom/dicom/build/"></iframe>
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<!--maincontainer-->
<div class="container" style="width:100%" id="maincontainer">

		
		<div class="row" id="mainrow" style="margin:0px">
		<!-- tabholder -->
				<?php include 'snippets/tabholder.php' ?>

		<!-- profileholder -->
				<?php include 'snippets/profile.php' ?>

		<!-- reportcontainer -->
			<div class="col col-sm-12 col-md-12 col-lg-6" id="reportholder" style="padding:0px;height:220px;overflow:scroll">
			<div ng-view></div>
		
				
			</div>

		<!-- search and list container -->
				<?php include 'snippets/list.php' ?>

		</div>


</div>

  <script type="text/javascript">
 
  document.onreadystatechange = function(e)
{
    if (document.readyState === 'complete')
    {
        //dom is ready, window.onload fires later
        	$.ajax({
  		method:"post",
  		url:"json/latestresponse.json",
  		success:function(){
  			//REPORT DATA
  			console.log(arguments[0].testDetails);
  			var reportlist=[];
  			var yearsarray=Object.keys(arguments[0].testDetails);
  			for(i=0;i<yearsarray.length;i++)
  			{
  				var currentobj=Object.keys(arguments[0].testDetails[yearsarray[i]]);
  				console.log(currentobj);
  				for(j=0;j<currentobj.length;j++)
  				{
  					reportlist.push({year:yearsarray[i],reportName:currentobj[j],observations:arguments[0].testDetails[yearsarray[i]][currentobj[j]],timestamp:arguments[0].testDetails[yearsarray[i]][currentobj[j]][0].timeStamp});
  				}
  			}
  			console.log(reportlist);
  			window.reportData=reportlist;
  			
  		},
  		error:function(){
  			console.log(arguments[0]);
  		}
  	});
    }
};
 window.document.onload=function(){

  		console.log("***********"); 
  		console.log(window.reportData);



  }

var app=angular.module("reportDash",["ngRoute"]);
app.config(function($routeProvider){
	$routeProvider.when("/",{
		templateUrl:"partials/default.html"
	}).when("/reports/:id",{
		templateUrl:"partials/report.html"
	});
});
app.controller("maincontroller",['$scope','$window',function($scope,$window){

	
	console.log($window);
	$scope.reports=$window.reportData;
  $scope.$watch($window.reportData,function(){
      $scope.reports=$window.reportData;
  });
	console.log("@@@@@@@@");
	console.log($scope.reports);
	$scope.generateReport=function(mark)
	{
		//alert(mark);
		console.log($scope.reports[mark]);
		console.log($scope.reports[mark].observations);
		$scope.observationarray=$scope.reports[mark].observations;
		$scope.reportarray=[];
		for(k=0;k<$scope.observationarray.length;k++)
		{
			var observationsubkeyarray=Object.keys($scope.observationarray[k].observationDetails);
			var observationobj=JSON.parse($scope.observationarray[k].observationDetails[observationsubkeyarray[0]]);
			console.log(observationobj);
			console.log(observationsubkeyarray);
			 $scope.reportarray.push({
				label:observationobj.Observation_identifier.Observation_Text,
				range:observationobj.Result_unit_reference_range,
				value:observationobj.Observation_value,
				unit:observationobj.Result_units_of_measurement,
				abnormal:observationobj.Abnormal_flags
			});
		}
	
		$scope.modalheader=event.target.innerText;
			


	}

}]);

  </script>
</body>
</html>